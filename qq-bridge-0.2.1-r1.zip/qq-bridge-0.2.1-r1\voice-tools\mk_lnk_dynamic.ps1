﻿$ws = New-Object -ComObject WScript.Shell
$desktop = [Environment]::GetFolderPath("Desktop")
$lnk = Join-Path $desktop "QQ后台.lnk"
$sc = $ws.CreateShortcut($lnk)
$sc.TargetPath = "C:\Windows\System32\wscript.exe"
$sc.Arguments = '"C:\Users\Administrator\Documents\deepseek-harness\default-workspace\qq-bridge-main\voice-tools\open-console.vbs"'
$sc.Description = "打开 QQ 桥接控制台（每次读取最新令牌）"
$sc.IconLocation = "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe,0"
$sc.Save()
Write-Output ("created=" + $lnk)
