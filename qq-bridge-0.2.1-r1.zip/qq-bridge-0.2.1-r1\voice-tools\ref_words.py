import os
import subprocess
import tempfile
import wave

import numpy as np
from faster_whisper import WhisperModel

HERE = os.path.dirname(os.path.abspath(__file__))
FFMPEG = os.environ.get("FFMPEG_PATH") or "ffmpeg"
REF = os.path.join(HERE, "ref", "manbo_ref.wav")

tmp = os.path.join(tempfile.gettempdir(), "ref16.wav")
subprocess.run([FFMPEG, "-hide_banner", "-loglevel", "error", "-y", "-i", REF, "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", tmp], check=True)
w = wave.open(tmp)
a = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768

m = WhisperModel("small", device="cpu", compute_type="int8")
segs, _ = m.transcribe(a, language="zh", word_timestamps=True, vad_filter=False)
for s in segs:
    print(f"[{s.start:.2f}-{s.end:.2f}] {s.text}")
    if s.words:
        for wd in s.words:
            print(f"    {wd.start:.2f}-{wd.end:.2f} {wd.word} ({wd.probability:.2f})")
