#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""用新的参考音色（ref/xinyu_ref.wav）重新生成整套语音库。"""
import os, sys, shutil, json
HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)
sys.path.insert(0, HERE)

import f5_backend as F
from gen import to_wav16

REF = os.path.join(HERE, "ref", "xinyu_ref.wav")
REF_TEXT = "好嘛，这条发完就先歇会儿啦。收到了，这样听着清楚吗？"
F.REF_AUDIO = REF
F.REF_TEXT = REF_TEXT

AUDIO = os.path.abspath(os.path.join(HERE, "..", "audio"))
LINES = {
    "在的在的": "在的在的，我在呢",
    "好耶": "好耶，太好啦",
    "才不理你": "哼，才不理你呢",
    "晚安": "晚安啦，做个好梦哦",
    "让我想想": "唔…让我想一想",
    "真的假的": "真的假的呀",
    "困了": "我有点困了呢",
    "哎呀": "哎呀，你怎么这样",
    "你说啥": "啊？你说啥",
    "收到收到": "收到收到，我知道啦",
    "哈哈哈": "哈哈哈，你也太逗了",
    "牛啊": "哇，好厉害，牛啊",
    "试音": "喂喂，能听见我说话吗？这是试音，一二三四五",
}

def main():
    out = {}
    for name, text in LINES.items():
        tmp = os.path.join(HERE, "out", "relib_%s.wav" % abs(hash(name)))
        F.synth(text, tmp, speed=1.0)
        dst = os.path.join(AUDIO, name + ".wav")
        if os.path.exists(dst):
            shutil.copy2(dst, dst + ".old")
        to_wav16(tmp, dst)
        os.remove(tmp)
        out[name] = round(os.path.getsize(dst) / 1024, 1)
        print("ok", name, out[name], "KB")
    print(json.dumps(out, ensure_ascii=False))

if __name__ == "__main__":
    main()