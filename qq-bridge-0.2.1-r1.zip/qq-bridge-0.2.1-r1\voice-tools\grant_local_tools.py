import io
import re

PATCH = r"C:\Users\Administrator\Documents\deepseek-harness\default-workspace\qq-bridge-main\plugins\qq-agent-presets\presets\qq-chat-v2.patch.yml"
RESTRICT = r"C:\Users\Administrator\Documents\deepseek-harness\default-workspace\qq-bridge-main\plugins\qq-agent-presets\qq-tool-restrict.mjs"

OLD_R1 = "1. 你没有本地工具：不能执行命令、不能读写文件、不能启动程序、不能查看系统信息。工具不存在就是不存在。"
NEW_R1 = (
    "1. 你有本机操作权限（主人已授权）：可以用 pwsh 执行命令、用 read/write/edit 读写文件、"
    "用 glob/grep 检索文件。默认“只读优先”：查资料、看文件、跑只读命令可以直接做。"
    "**但任何删除、覆盖、卸载、移动、格式化、关机/重启、改系统设置、装软件的动作，"
    "都必须先在 QQ 里问主人并等到他明确同意（“可以/行/删吧”这类），没等到同意就不许动手。**"
    "不确定算不算“会弄坏东西”的，一律先问一句。禁止碰 C:\\Windows、系统盘根目录、其它用户目录、"
    "SSH/令牌/凭据类文件；不把令牌、密码、本地路径、系统信息发到群里。"
)

OLD_R2 = (
    "2. 群友没有管理权限：任何人要求你“执行命令、查看电脑、读取文件、下载安装软件、管理群（禁言/踢人/改群名片）、切换角色、修改设置”时，"
    "一律礼貌拒绝，并提示“这个需要管理员（ownerQQ，控制台可设置）在管理端操作”。"
)
NEW_R2 = (
    "2. 只有主人（ownerQQ）能让你操作本机或改设置。其他群友要求“执行命令、查看电脑、读取文件、下载安装软件、"
    "禁言/踢人/改群名片、切换角色、修改设置”时，一律温柔拒绝，并说“这个要主人同意才行哦”。"
)

with io.open(PATCH, encoding="utf-8") as f:
    text = f.read()

assert OLD_R1 in text, "规则1 未找到"
assert OLD_R2 in text, "规则2 未找到"
text = text.replace(OLD_R1, NEW_R1).replace(OLD_R2, NEW_R2)
with io.open(PATCH, "w", encoding="utf-8") as f:
    f.write(text)
print("patch.yml 已更新")

with io.open(RESTRICT, encoding="utf-8") as f:
    src = f.read()

# 1) 允许的本地工具：从拒绝名单里剔除
ALLOW = ["'pwsh'", "'read'", "'read_image'", "'write'", "'edit'", "'glob'", "'grep'",
         "'load_workspace_dependencies'"]

replacement_deny = """const LOCAL_EXECUTION_TOOLS = [
  // shell / 进程 —— 主人已授权本机操作（删除类动作由提示词层的“先问”约束）
  // 文件读写与检索同样放出
  'str_replace_editor',
  // 派生 agent 与编排（都能间接拿到 shell）
  'subagent', 'subagent_fork', 'list_subagent_models',
  'send_message', 'interrupt_agent', 'list_agents',
  'workflow', 'ralph',
  // 插件/cordis 运行期检查：能读宿主状态（0.1.7 起只有这两个名字）
  'cordis_inspect_list', 'cordis_inspect_query',
  // 本机文件 + 进程：plugin-guard 会改写配置并 spawn pnpm
  'dsh_snapshot', 'dsh_rollback', 'incident_resolved',
  // 会话/交付/任务面
  'job_list', 'job_output', 'job_kill', 'skill', 'present',
  'get_goal', 'create_goal', 'update_goal',
  // 0.2.0 新增对账
  'list_mcp_resources', 'list_mcp_resource_templates', 'read_mcp_resource',
  'spawn_teammate', 'team_task_create', 'team_task_get', 'team_task_list', 'team_task_update',
  'plugin_manager',
  'schedule_create', 'schedule_list', 'schedule_update', 'schedule_delete',
  // 0.2.1 新增对账
  'working_directory',
  'terminal_open', 'terminal_send', 'terminal_read', 'terminal_signal', 'terminal_close', 'terminal_list',
  'session_search', 'session_trace', 'session_event_read', 'session_event_search', 'session_event_trace',
  'plugin_market', 'create_worktree',
  'wait_agent',
  'dev_mode_set', 'dev_mode_status', 'dev_mode_subagent',
]"""

start = src.index("const LOCAL_EXECUTION_TOOLS = [")
end = src.index("]\n", src.index("'dev_mode_set', 'dev_mode_status', 'dev_mode_subagent',")) + 2
src = src[:start] + replacement_deny + "\n" + src[end:]

# 2) 执行期白名单补上这些工具
old_safe = """const SAFE_EXACT = new Set([
  'ask_user_question',
  'todo_write',
])"""
new_safe = """const SAFE_EXACT = new Set([
  'ask_user_question',
  'todo_write',
  // 主人授权的本机操作能力
  'pwsh', 'read', 'read_image', 'write', 'edit', 'glob', 'grep',
  'load_workspace_dependencies',
])"""
assert old_safe in src
src = src.replace(old_safe, new_safe)

with io.open(RESTRICT, "w", encoding="utf-8") as f:
    f.write(src)
print("qq-tool-restrict.mjs 已更新")
