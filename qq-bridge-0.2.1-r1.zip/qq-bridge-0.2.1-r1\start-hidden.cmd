@echo off
rem Launcher for the Startup folder: make sure node is on PATH, then hand over to start.bat.
rem start.bat loops and restarts the bridge 5s after any crash.
rem Keep this file CRLF: cmd.exe mis-parses LF-only batch files.
set "PATH=C:\Program Files\nodejs;%PATH%"
cd /d "%~dp0"
call "%~dp0start.bat"
