#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""生成一条「试音」语音：把几种音色挨个说同一句话，拼成一条发出去"""
import os
import sys
import subprocess
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gen

SENTENCE = "今天天气不错呀，要不要一起出去玩"
VARIANTS = [
    ("一号，晓晓，温柔一点", "zh-CN-XiaoxiaoNeural", "+0Hz"),
    ("二号，晓伊，卡通风", "zh-CN-XiaoyiNeural", "+12Hz"),
    ("三号，晓伊再高一点", "zh-CN-XiaoyiNeural", "+30Hz"),
    ("四号，晓晓高一点", "zh-CN-XiaoxiaoNeural", "+20Hz"),
    ("五号，云希，男声阳光", "zh-CN-YunxiNeural", "+0Hz"),
    ("六号，云夏，正太音", "zh-CN-YunxiaNeural", "+0Hz"),
]


def main():
    parts = []
    for i, (label, voice, pitch) in enumerate(VARIANTS):
        lp = os.path.join(tempfile.gettempdir(), f"aud_{i}_label.mp3")
        gen.tts_raw(label, "zh-CN-XiaoxiaoNeural", lp, pitch="+0Hz")
        lw = os.path.join(tempfile.gettempdir(), f"aud_{i}_label.wav")
        gen.to_wav16(lp, lw)

        sp = os.path.join(tempfile.gettempdir(), f"aud_{i}_say.mp3")
        gen.tts_raw(SENTENCE, voice, sp, pitch=pitch)
        sw = os.path.join(tempfile.gettempdir(), f"aud_{i}_say.wav")
        gen.to_wav16(sp, sw)

        gap = os.path.join(tempfile.gettempdir(), f"aud_{i}_gap.wav")
        subprocess.run([gen.FFMPEG, "-y", "-hide_banner", "-loglevel", "error",
                        "-f", "lavfi", "-i", "anullsrc=r=16000:cl=mono", "-t", "0.35",
                        "-c:a", "pcm_s16le", gap], check=True)
        parts += [lw, gap, sw, gap]

    listfile = os.path.join(tempfile.gettempdir(), "aud_list.txt")
    with open(listfile, "w", encoding="utf-8") as f:
        for p in parts:
            f.write("file '%s'\n" % p.replace("\\", "/"))
    joined = os.path.join(tempfile.gettempdir(), "aud_joined.wav")
    subprocess.run([gen.FFMPEG, "-y", "-hide_banner", "-loglevel", "error",
                    "-f", "concat", "-safe", "0", "-i", listfile, "-c", "copy", joined], check=True)

    out = os.path.join(gen.AUDIO_DIR, "试音.wav")
    subprocess.run([gen.FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-i", joined,
                    "-af", "loudnorm=I=-16:TP=-1.5:LRA=11",
                    "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le", out], check=True)
    print(out, "%.1fs" % gen.ffprobe_duration(out))


if __name__ == "__main__":
    main()
