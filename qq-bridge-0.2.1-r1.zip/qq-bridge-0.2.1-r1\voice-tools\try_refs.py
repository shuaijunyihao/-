"""曼波音色克隆试验：不同参考文本 / 不同参考片段的效果对比。"""
import os
import sys

os.environ.setdefault("HF_ENDPOINT", "https://hf-mirror.com")
os.environ.setdefault("HF_HUB_DISABLE_XET", "1")

import numpy as np
import torch
import torchaudio
from f5_tts.api import F5TTS

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "out")
os.makedirs(OUT, exist_ok=True)

TEXT = "你好呀，我是小肥。"

CASES = [
    # (名字, 参考音频, 参考文本, 语速)
    ("h1_clip", os.path.join(HERE, "ref", "manbo_ref_clip.wav"),
     "まつりマンボ まっしゃいマンボ まつりマンボ", 1.0),
    ("h2_full", os.path.join(HERE, "ref", "manbo_ref16.wav"),
     "まつりマンボ まっしゃいマンボ まつりマンボ ゆるだゆるだ まつりマンボ", 1.0),
    ("h3_clip_fast", os.path.join(HERE, "ref", "manbo_ref_clip.wav"),
     "まつりマンボ まっしゃいマンボ まつりマンボ", 1.15),
]

model = F5TTS(model="F5TTS_v1_Base", device="cuda")
for name, ref, reftext, speed in CASES:
    torch.manual_seed(1234)
    wav, sr, _ = model.infer(ref_file=ref, ref_text=reftext, gen_text=TEXT, speed=speed,
                             show_info=lambda *a, **k: None)
    arr = np.asarray(wav)
    if arr.ndim == 1:
        arr = arr[None, :]
    p = os.path.join(OUT, name + ".wav")
    torchaudio.save(p, torch.from_numpy(arr.astype("float32")).cpu(), sr)
    print(f"{name}: {arr.shape[-1]/sr:.2f}s", flush=True)
