"""用 F5-TTS 以曼波参考音频克隆音色，批量合成语音库/句子。"""
import os
import sys
import time

os.environ.setdefault("HF_ENDPOINT", "https://hf-mirror.com")
os.environ.setdefault("HF_HUB_DISABLE_XET", "1")

import torch
import torchaudio  # noqa: F401
from f5_tts.api import F5TTS

HERE = os.path.dirname(os.path.abspath(__file__))
REF = os.path.join(HERE, "ref", "manbo_ref16.wav")
REF_TEXT = "曼波曼波曼波曼波曼波曼波曼波曼波"

_model = None


def get_model(device="cuda"):
    global _model
    if _model is None:
        t0 = time.time()
        _model = F5TTS(model="F5TTS_v1_Base", device=device)
        print(f"[f5] 模型加载 {time.time()-t0:.1f}s", flush=True)
    return _model


def synth(text, out_path, speed=1.0, seed=None, device="cuda", ref_audio=None, ref_text=None):
    m = get_model(device)
    if seed is not None:
        torch.manual_seed(seed)
    t0 = time.time()
    wav, sr, _ = m.infer(
        ref_file=ref_audio or REF,
        ref_text=ref_text or REF_TEXT,
        gen_text=text,
        speed=speed,
        show_info=lambda *a, **k: None,
    )
    import numpy as np

    arr = np.asarray(wav)
    if arr.ndim == 1:
        arr = arr[None, :]
    torchaudio.save(out_path, torch.from_numpy(arr.astype("float32")).cpu(), sr)
    dur = arr.shape[-1] / sr
    print(f"[f5] {os.path.basename(out_path)} {dur:.2f}s 用 {time.time()-t0:.1f}s", flush=True)
    return out_path


if __name__ == "__main__":
    outdir = os.path.join(HERE, "out")
    os.makedirs(outdir, exist_ok=True)
    tests = [
        ("你好呀，我是小肥。", 1.0, os.path.join(outdir, "t_a.wav")),
        ("你好呀，我是小肥。", 1.15, os.path.join(outdir, "t_b.wav")),
        ("今天天气不错，要不要一起出去逛逛？", 1.0, os.path.join(outdir, "t_c.wav")),
    ]
    for text, sp, p in tests:
        synth(text, p, speed=sp)
