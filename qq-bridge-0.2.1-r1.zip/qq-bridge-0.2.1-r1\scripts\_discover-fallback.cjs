// dsh-bigfish / _discover-fallback.cjs
//
// doctor.mjs 在插件还没安装、或者 dsh-bigfish/lib/discover.js 加载失败时
// 用的精简替身。只保留 doctor 真正需要的那部分能力，逻辑与 discover.js
// 保持一致，但不依赖插件目录结构。
//
// 不要在这里加花活。它的唯一职责是「插件不在时也能体检」。
const fs = require('node:fs')
const os = require('node:os')
const net = require('node:net')
const path = require('node:path')
const http = require('node:http')
const { execFileSync } = require('node:child_process')

const IS_WINDOWS = process.platform === 'win32'
const DSH_HOME = process.env.DSH_HOME || path.join(os.homedir(), '.dsh')
const SAVED_FILE = path.join(DSH_HOME, 'plugins', 'dsh-bigfish', 'bridge-home.json')

function exists(p) {
  try { fs.accessSync(p); return true } catch { return false }
}
function isDir(p) {
  try { return fs.statSync(p).isDirectory() } catch { return false }
}
function isBridgeHome(dir) {
  if (!dir || typeof dir !== 'string') return false
  return ['src/bridge.js', 'config.json', 'admin/server.py'].every((f) => exists(path.join(dir, f)))
}

function rememberBridgeHome(dir) {
  if (!isBridgeHome(dir)) return false
  try {
    fs.mkdirSync(path.dirname(SAVED_FILE), { recursive: true })
    fs.writeFileSync(SAVED_FILE, JSON.stringify({ home: dir, at: new Date().toISOString() }, null, 2))
    return true
  } catch { return false }
}
function rememberedBridgeHome() {
  try {
    const j = JSON.parse(fs.readFileSync(SAVED_FILE, 'utf8'))
    return j && j.home && isBridgeHome(j.home) ? j.home : null
  } catch { return null }
}

function findBridgeHome(opts = {}) {
  const tried = []
  const push = (dir, from) => {
    if (!dir) return null
    const abs = path.resolve(dir)
    const ok = isBridgeHome(abs)
    tried.push({ dir: abs, from, ok })
    return ok ? abs : null
  }

  let hit = push(process.env.QQ_BRIDGE_HOME, 'QQ_BRIDGE_HOME')
  if (hit) { rememberBridgeHome(hit); return { home: hit, tried } }

  hit = push(opts.extra, '手动指定')
  if (hit) { rememberBridgeHome(hit); return { home: hit, tried } }

  hit = push(rememberedBridgeHome(), '记忆文件')
  if (hit) return { home: hit, tried }

  // 候选目录扫描
  const home = os.homedir()
  const candidates = []
  const baseNames = ['qq-bridge-main', 'qq-bridge', 'dafeiyu', 'bigfish']
  const parents = [
    home,
    path.join(home, 'Desktop'),
    path.join(home, 'Documents'),
    path.join(home, 'Downloads'),
    path.join(home, 'source'),
    path.join(home, 'code'),
    path.join(home, 'projects'),
    path.join(home, 'Documents', 'deepseek-harness', 'default-workspace'),
  ]
  for (const p of parents) {
    for (const n of baseNames) candidates.push(path.join(p, n))
  }
  // 家目录下的一级子目录里再找一层
  try {
    for (const entry of fs.readdirSync(home, { withFileTypes: true })) {
      if (!entry.isDirectory() || entry.name.startsWith('.')) continue
      for (const n of baseNames) candidates.push(path.join(home, entry.name, n))
    }
  } catch {}
  // 各盘符根目录
  if (IS_WINDOWS) {
    for (const drive of ['C:', 'D:', 'E:', 'F:']) {
      for (const n of baseNames) candidates.push(drive + '\\' + n)
    }
  }

  const seen = new Set()
  for (const c of candidates) {
    const abs = path.resolve(c)
    if (seen.has(abs)) continue
    seen.add(abs)
    if (!isDir(abs)) { tried.push({ dir: abs, from: '扫描', ok: false }); continue }
    if (push(abs, '扫描')) {
      rememberBridgeHome(abs)
      return { home: abs, tried }
    }
  }
  return { home: null, tried }
}

function whichOnPath(name) {
  const dirs = (process.env.PATH || '').split(path.delimiter).filter(Boolean)
  const exts = IS_WINDOWS ? (process.env.PATHEXT || '.EXE;.CMD;.BAT').split(';') : ['']
  for (const d of dirs) {
    for (const e of exts) {
      const p = path.join(d, name + (name.toLowerCase().endsWith(e.toLowerCase()) ? '' : e))
      if (exists(p)) return p
    }
  }
  return null
}

function findPython(preferConsole = false) {
  // preferConsole=true → 只接受 python.exe（pythonw 会在无控制台场景静默失败）
  const names = preferConsole ? ['python.exe'] : ['python.exe', 'pythonw.exe']
  // 1. DSH 自带运行时
  const bundled = [
    path.join(DSH_HOME, 'dsh-runtimes', 'dsh-primary-runtime', 'dependencies', 'python'),
  ]
  for (const base of bundled) {
    for (const n of names) {
      const p = path.join(base, n)
      if (exists(p)) return p
    }
  }
  // 2. PATH
  for (const n of (preferConsole ? ['python'] : ['python', 'python3'])) {
    const p = whichOnPath(n)
    if (p) return p
  }
  // 3. 常见安装位置
  const guesses = [
    path.join(os.homedir(), 'AppData', 'Local', 'Programs', 'Python'),
    'C:\\Python312', 'C:\\Python311', 'C:\\Python310',
  ]
  for (const g of guesses) {
    if (!isDir(g)) continue
    if (g.endsWith('Python')) {
      try {
        for (const sub of fs.readdirSync(g)) {
          for (const n of names) {
            const p = path.join(g, sub, n)
            if (exists(p)) return p
          }
        }
      } catch {}
    } else {
      for (const n of names) {
        const p = path.join(g, n)
        if (exists(p)) return p
      }
    }
  }
  return null
}

function findNode() {
  return process.execPath || whichOnPath('node')
}

function portOpen(port, host = '127.0.0.1', timeout = 700) {
  return new Promise((resolve) => {
    const s = net.connect({ port, host })
    let done = false
    const finish = (v) => { if (!done) { done = true; try { s.destroy() } catch {}; resolve(v) } }
    s.setTimeout(timeout)
    s.on('connect', () => finish(true))
    s.on('timeout', () => finish(false))
    s.on('error', () => finish(false))
  })
}

function listeningPorts() {
  if (!IS_WINDOWS) {
    try {
      const out = execFileSync('ss', ['-ltnp'], { encoding: 'utf8', timeout: 5000 })
      return out.split('\n').slice(1).map((l) => {
        const m = l.match(/:(\d+)\s/)
        return m ? { port: Number(m[1]), pid: 0 } : null
      }).filter(Boolean)
    } catch { return [] }
  }
  let out = ''
  try {
    out = execFileSync('netstat', ['-ano'], { encoding: 'utf8', timeout: 8000, windowsHide: true })
  } catch { return [] }
  const rows = []
  for (const line of out.split(/\r?\n/)) {
    const parts = line.trim().split(/\s+/)
    if (parts.length < 5) continue
    if (!/^TCP$/i.test(parts[0])) continue
    if (!/LISTENING/i.test(parts[3])) continue
    const local = parts[1]
    const m = String(local).match(/:(\d+)$/)
    if (!m) continue
    const port = Number(m[1])
    if (!port || port < 1024) continue
    const addr = local.slice(0, local.lastIndexOf(':'))
    if (!['0.0.0.0', '127.0.0.1', '[::]', '[::1]'].includes(addr)) continue
    rows.push({ port, pid: Number(parts[4]) || 0 })
  }
  return rows
}

function pidOnPort(port) {
  const hit = listeningPorts().find((r) => r.port === port)
  return hit ? hit.pid : 0
}

function httpGet(url, timeout = 1500) {
  return new Promise((resolve) => {
    let u
    try { u = new URL(url) } catch { return resolve(null) }
    const req = http.request({
      host: u.hostname, port: u.port || 80, path: u.pathname + u.search,
      method: 'GET', timeout,
      headers: { 'user-agent': 'dsh-bigfish.doctor/fallback' },
    }, (res) => {
      const chunks = []
      res.on('data', (c) => chunks.push(c))
      res.on('end', () => resolve({
        status: res.statusCode || 0,
        headers: res.headers,
        body: Buffer.concat(chunks).toString('utf8'),
      }))
      res.on('error', () => resolve(null))
    })
    req.on('timeout', () => { try { req.destroy() } catch {}; resolve(null) })
    req.on('error', () => resolve(null))
    req.end()
  })
}

const SKIP = new Set([3000, 3001, 3100, 3200, 5099])

async function detectDshPort() {
  if (process.env.DSH_WEB_PORT) return { port: Number(process.env.DSH_WEB_PORT), from: 'env' }
  const cands = listeningPorts()
    .map((r) => r.port)
    .filter((p, i, a) => !SKIP.has(p) && p >= 1024 && a.indexOf(p) === i)
  const probes = await Promise.all(cands.map(async (p) => {
    const r = await httpGet('http://127.0.0.1:' + p + '/dsh-bigfish/ping', 900)
    return r && r.headers && String(r.headers['x-served-by'] || '').includes('dsh-bigfish') ? p : null
  }))
  const found = probes.filter(Boolean)
  return { port: found.length ? found[0] : null, from: found.length ? 'ping' : 'none' }
}

const configPath = (home) => path.join(home, 'config.json')

function readConfig(home) {
  try { return JSON.parse(fs.readFileSync(configPath(home), 'utf8')) } catch { return null }
}

function writeConfigBaseUrl(home, port) {
  const p = configPath(home)
  let raw
  try { raw = fs.readFileSync(p, 'utf8') } catch (e) { return { ok: false, error: '读不到 config.json: ' + e.message } }
  const re = /("baseUrl"\s*:\s*"http:\/\/127\.0\.0\.1:)(\d+)/
  if (!re.test(raw)) return { ok: false, error: 'config.json 里没有形如 "baseUrl": "http://127.0.0.1:端口" 的字段' }
  const before = raw.match(re)[2]
  if (Number(before) === Number(port)) return { ok: true, changed: false, from: before }
  const next = raw.replace(re, '$1' + port)
  try {
    fs.writeFileSync(p, next, 'utf8')
    return { ok: true, changed: true, from: before, to: port }
  } catch (e) { return { ok: false, error: e.message } }
}

function backupConfig(home, tag = 'doctor') {
  const p = configPath(home)
  if (!exists(p)) return null
  const dst = p + '.bak-' + tag + '-' + Date.now()
  try { fs.copyFileSync(p, dst); return dst } catch { return null }
}

function readConsoleToken(home) {
  try { return fs.readFileSync(path.join(home, 'state', 'console-token'), 'utf8').trim() } catch { return '' }
}

function tailFile(p, n = 40) {
  try {
    const raw = fs.readFileSync(p, 'utf8')
    const lines = raw.split(/\r?\n/).filter((l) => l.length)
    return lines.slice(-n)
  } catch { return [] }
}

module.exports = {
  DSH_HOME, IS_WINDOWS, SAVED_FILE,
  exists, isDir, isBridgeHome, rememberBridgeHome, rememberedBridgeHome, findBridgeHome,
  findPython, whichOnPath, findNode,
  portOpen, listeningPorts, pidOnPort, httpGet, detectDshPort,
  configPath, readConfig, writeConfigBaseUrl, backupConfig, readConsoleToken, tailFile,
}
