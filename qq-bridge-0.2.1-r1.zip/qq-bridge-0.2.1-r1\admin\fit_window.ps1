$ErrorActionPreference = 'SilentlyContinue'
Add-Type -AssemblyName System.Windows.Forms
Start-Sleep -Seconds 4

Add-Type @'
using System;
using System.Runtime.InteropServices;
public class FitWin {
  [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr hWnd, IntPtr after, int x, int y, int cx, int cy, uint flags);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int cmd);
}
'@

$area = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$w = [int]($area.Width * 0.94)
$h = [int]($area.Height * 0.92)
$x = [int]($area.X + ($area.Width - $w) / 2)
$y = [int]($area.Y + 8)

$win = Get-Process msedge | Where-Object { $_.MainWindowTitle -like '*后台*' } | Select-Object -First 1
if (-not $win) { exit }

[FitWin]::ShowWindow($win.MainWindowHandle, 9) | Out-Null
[FitWin]::SetWindowPos($win.MainWindowHandle, [IntPtr]::Zero, $x, $y, $w, $h, 0x0040) | Out-Null