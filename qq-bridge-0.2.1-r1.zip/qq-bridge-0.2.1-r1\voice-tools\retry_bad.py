#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""两步走：先按多个种子批量合成到 out/retry，再单独起进程做 ASR 回读，挑最像的写入语音库。

（faster-whisper 和 torch 同时加载会撞 cudnn 符号，所以 ASR 必须放在独立进程跑。）
"""
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
os.environ["VOICE_ENGINE"] = "f5"

TARGETS = [
    ("你说啥", "啊？你说啥"),
    ("牛啊", "哇，牛啊"),
    ("哈哈哈", "哈哈哈哈哈"),
    ("收到收到", "收到收到，明白啦"),
]
SEEDS = [1234, 7, 21, 99, 555, 2024]


def main():
    import gen
    import f5_backend

    audio = gen.AUDIO_DIR
    outdir = os.path.join(HERE, "retry")
    os.makedirs(outdir, exist_ok=True)
    for f in os.listdir(outdir):
        os.remove(os.path.join(outdir, f))

    mapping = {}
    for name, text in TARGETS:
        for seed in SEEDS:
            raw = os.path.join(outdir, f"{name}__{seed}.wav")
            f5_backend.synth(text, raw, seed=seed, speed=0.95)
        mapping[name] = text
        print(f"合成完毕 {name}", flush=True)
    print("全部合成完成", flush=True)


if __name__ == "__main__":
    main()
