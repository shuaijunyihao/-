@echo off
chcp 65001 >nul
cd /d "%~dp0"
rem Harden state/ ACLs (Windows needs WRITE_DAC; the directory owner normally has it,
rem so no UAC prompt in the usual case). This NEVER blocks startup: if it cannot get
rem permission it prints a copy-pasteable command and exits 0.
rem See docs/guides/SECURITY_BASELINE.md ("secrets at rest").
node scripts\harden-state-acl.mjs --quiet
rem Keep config.json dsh.baseUrl aligned with DSH's web port. DSH picks a new
rem random port on every restart; a stale address makes the bridge connect to a
rem dead port and go silent (dshReady=false, mode falls back to chat).
rem Runs in background: it rewrites config.json and asks the bridge to restart.
start "" /b node scripts\dsh-port-sync.mjs --watch
:loop
node src/bridge.js
set code=%errorlevel%
if "%code%"=="2" (
    rem Exit code 2 means the console port was busy. Never "pause" here: this loop
    rem runs in a hidden window, so a pause would hang forever and the bridge would
    rem stay dead. Wait and re-check instead.
    echo [%date% %time%] bridge already running in another window, retrying in 30 seconds...
    timeout /t 30 /nobreak >nul
    goto loop
)
echo [%date% %time%] bridge exited (code %code%), restarting in 5 seconds...
timeout /t 5 /nobreak >nul
goto loop
