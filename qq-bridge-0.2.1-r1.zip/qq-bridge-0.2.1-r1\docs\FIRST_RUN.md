# 第一次使用：从下载到她在群里说话

> 这份文档面向**刚下载本项目的用户**。照着做，大约 20 分钟就能让 QQ 机器人在群里回话。
> 遇到问题先看最后一节「出问题怎么办」，或者打开 DSH 右下角的 🐟 按钮点「体检」。

---

## 0. 你需要先准备三样东西

| 东西 | 说明 | 去哪弄 |
| --- | --- | --- |
| **DeepSeek-Harness（DSH）** | 真正在"思考"和回话的大脑。本项目只是它的 QQ 外壳。 | 官方安装包，装完能打开 Web 界面即可 |
| **SnowLuma** | 把 QQ 消息转成 OneBot 协议的网关（相当于 QQ 的插座）。 | <https://github.com/SnowLuma/SnowLuma> |
| **Node.js ≥ 22.13** | 桥接程序的运行环境。 | <https://nodejs.org/> 选 LTS |

另外需要一个**能登录 QQ 的账号**（建议用小号，别用主号）。

> ⚠️ 三个组件的分工别搞混：
> **QQ ↔ SnowLuma ↔ qq-bridge（本项目）↔ DSH ↔ 模型**
> 任何一环没起来，表现都是"她不说话"。

---

## 1. 解压到一个**路径里没有中文和空格**的目录

比如 `D:\qq-bridge\`。

> ❗ 不要把项目放在 `C:\Program Files\`、桌面、或者带中文的路径下。
> Windows 的权限和编码问题会让语音、Python 脚本莫名其妙地失败。

---

## 2. 安装依赖

打开命令行（在项目目录里按住 Shift + 右键 →「在此处打开 PowerShell 窗口」），执行：

```powershell
npm install
```

- 会下载约 30MB 依赖，第一次大约 1–3 分钟。
- 安装完会自动跑一个修补脚本（修 `@snowluma/sdk` 的 ESM 导入 bug），**看到 `postinstall` 相关的输出是正常的**。
- 如果报 peer dependency 冲突：项目自带 `.npmrc`（`legacy-peer-deps=true`），确认这个文件还在。

---

## 3. 生成配置文件

```powershell
copy config.example.json config.json
```

然后用记事本 / VSCode 打开 `config.json`，只需要改**四处**：

```jsonc
{
  "ownerQQ": 你的QQ号,              // ← 改成你自己的 QQ 号（主人）
  "dsh": {
    "baseUrl": "http://127.0.0.1:3080"   // ← 改成你 DSH 的实际地址，见下方说明
  },
  "snowluma": {
    "accessToken": "你的SnowLuma令牌",    // ← 从 SnowLuma 界面复制
    "wsUrl": "ws://127.0.0.1:3001",
    "httpUrl": "http://127.0.0.1:3000"
  },
  "consoleToken": "随便设一个长字符串"     // ← 后台面板的密码，别留空
}
```

**`dsh.baseUrl` 怎么填？**
打开你的 DSH，浏览器地址栏长这样：`http://127.0.0.1:50263/` —— 那个 `50263` 就是端口。
但 DSH **每次重启都会换端口**，所以本项目带了自动同步守护（见第 6 步），你只要保证这里先填对一次。

**`snowluma.accessToken` 在哪？**
打开 SnowLuma 的 WebUI（默认 `http://127.0.0.1:5099`）→ 设置 → OneBot → 复制 `access token`。
同时确认 OneBot 的 **WebSocket 端口是 3001、HTTP 端口是 3000**（不是的话改上面 `wsUrl`/`httpUrl`）。

> 💡 `snowluma.accessToken` 和 SnowLuma 的 **HTTP token** 是**两个不同的值**，别混。
> 桥接连不上时，日志里会明确写是哪一个错了。

---

## 4. 把 preset 和 MCP 装进 DSH（**最容易漏的一步**）

```powershell
node scripts\setup-dsh.mjs desktop
```

> 最后一个参数是 DSH 的 profile 名。不确定的话去 `C:\Users\你的用户名\.dsh\profiles\` 看一眼，
> 里面有几个文件夹就用哪个名字（常见是 `desktop` 或 `web`）。

这一步会做五件事：

1. 在 DSH 的 `cordis.patch.yml` 里挂上三个 MCP（SnowLuma 工具、宿主工具、联网搜索）；
2. 生成 / 刷新两个 agent preset（`qq-chat`、`qq-chat-v2`）；
3. 把 `qq-mode-console`、`qq-agent-presets`、**`dsh-bigfish`（🐟 面板）** 链进 DSH；
4. 把 `state/mode.json` 初始化成二代仿真模式；
5. 调用 `dsh plugin install` 落盘。

**装完必须重启 DSH**，否则面板和 preset 不会出现。

> 不想装 🐟 面板？加环境变量跳过：`$env:QQ_BRIDGE_SKIP_PANEL=1` 再跑。

---

## 5. 启动

双击项目根目录的 **`start.bat`**。

它会做三件事：
1. 修一下 `state/` 目录的权限（避免 Windows 拒绝访问）；
2. 后台起一个**端口同步守护**（DSH 换端口时自动改 `config.json` 并重启桥接）；
3. 起桥接主程序，并且**崩了会自动重连**。

看到类似这样的输出就说明起来了：

```
[snowluma] connected, account online
[console] http://127.0.0.1:3100
```

> 不要用「暂停」的方式关窗口——`start.bat` 里特意没写 `pause`，因为隐藏窗口会永久挂死。
> 想开机自启：把 `start-hidden.vbs` 的快捷方式丢进 `shell:startup`。

---

## 6. 打开面板，看体检

有两种打开方式，任选：

- **DSH 里**：界面右下角有个 🐟 按钮，点它 → 打开后台面板（推荐）
- **浏览器直连**：<http://127.0.0.1:3200/>

面板顶部四个灯：

| 灯 | 含义 |
| --- | --- |
| 桥接 | Node 主程序活着 |
| 网关 | SnowLuma 连上了 |
| DSH | 能找到 DSH 的 Web 端口 |
| QQ | QQ 账号在线 |

**四个全绿 + 横幅写「全部正常」= 装好了。**

有红的？点横幅右边的 **「一键修复」**，它只会跑安全的修复项（改配置、清残留锁、重启进程），不会删你的数据。
每个红项下面都能展开「为什么」，写清了这条检查在防什么坑。

---

## 7. 让她能跟谁说话：加白名单

面板里找到「白名单与目标」卡片：

1. 输入框填 **`你的QQ号`**（私聊）或 **`group:群号`**（群聊）→ 点「加入白名单」
2. 在左侧下拉里选中它 → 点 **「让她主动开口」**

如果几秒后你的 QQ 收到一条消息，说明**整条链路通了**。

> 出于安全，`allowAllWhenEmpty` 默认是 `false` —— 白名单为空时她**谁都不理**。
> 这是故意的，避免刚装好就被陌生人使唤。

---

## 8. 调她的性格

面板「角色与模式」：

- **角色**：`roles/*.md` 里的文件就是人格卡（`大肥鱼`、`温柔小鱼`、`傲娇助手`，也可以自己加）
- **模式**：
  - `reserved2` = **二代仿真**（推荐）：她像真人一样会潜水、会主动找话题、会发表情包
  - `closed-agent` = 旧模式：每条消息都回，比较机械

改完点「应用」，不用重启。

---

## 9. 可选：让她会说话（语音）

语音是**可选功能**，不装也能正常文字聊天。想开的话：

1. 装 Python 3.10+
2. 在 `voice-tools/` 里建虚拟环境并装依赖（见 `voice-tools/README.md`）
3. 首次用 F5-TTS 会下载模型（约 1–2GB）

面板「模块管理」卡片能看当前用的是哪个 Python，也能一键装 pip 包。

---

## 出问题怎么办

### 她不回话

按顺序查：

1. 面板四个灯是不是全绿？
2. 「日志」tab 选 `bridge`，看最后 20 行有没有 `ECONNREFUSED` / `401` / `timeout`
3. 点「体检」→ 看有没有红项
4. 确认 DSH 里 `qq-chat` preset 能用（随便在 DSH 里发一句话试试）

### 「连上了但收不到消息」

这是最常见的坑，三个原因：

- **WS token 和 HTTP token 填反了**（见第 3 步的提示）
- **SnowLuma 端点自愈把你写的 `wsUrl` 覆盖了** —— 看 `config.json` 里 `followDiscoveredEndpoint` 是不是 `true`（默认就该是 true，让它自己找）
- **QQ 号被风控**：SnowLuma 日志里会有提示，换个号试

### 面板打不开 / 404

- 直连 `http://127.0.0.1:3200/` 能开、DSH 里打不开 → 重启一次 DSH（插件代码是启动时加载的）
- 两个都打不开 → 桥接没起来，看 `start.bat` 的窗口

### 语音 / 翻唱失败

- 大概率是 Python 环境问题。面板「体检」里有 `python` 和 `voice` 两项检查
- **不要用 Microsoft Store 版的 python**（它是个存根，会静默失败返回 exit 49）
- 去 <https://www.python.org/> 装官方版，勾选 "Add to PATH"

### 一切正常但就是没反应

```powershell
node scripts\doctor.mjs
```

这是面板体检的命令行版，会打印 14 项检查的完整细节，比面板更啰嗦、更适合贴给别人看。

---

## 目录速查

| 路径 | 是什么 |
| --- | --- |
| `src/bridge.js` | 主程序（QQ ↔ DSH 的翻译官） |
| `admin/ui.html` | 后台面板页面 |
| `admin/server.py` | 面板的后端（Python 标准库，无第三方依赖） |
| `plugins/dsh-bigfish/` | DSH 里的 🐟 按钮插件 |
| `scripts/doctor.mjs` | 体检 / 一键修复 |
| `scripts/setup-dsh.mjs` | 往 DSH 里装 preset 和 MCP |
| `scripts/dsh-port-sync.mjs` | 端口漂移守护 |
| `roles/*.md` | 人格卡 |
| `voice-tools/` | 语音相关 Python 脚本（可选） |
| `state/` | 运行时状态、日志、锁（可以随便删，会自动重建） |
| `config.json` | 你的配置（**不要发给别人**，里面有 token） |

---

## 一句话总结

```powershell
npm install
copy config.example.json config.json   # 改 4 处
node scripts\setup-dsh.mjs desktop     # 然后重启 DSH
start.bat
```

打开面板 → 体检全绿 → 加白名单 → 让她主动开口 → 收到消息 = 成功。
