#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""用曼波音色（F5-TTS 克隆）重建语音库里的“说话”部分。"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ["VOICE_ENGINE"] = "f5"

import gen

LINES = [
    ("在的在的", "在的在的，我在呢"),
    ("好耶", "好耶！"),
    ("才不理你", "哼，才不理你"),
    ("晚安", "晚安啦，早点睡，别熬夜"),
    ("让我想想", "让我想想哦……"),
    ("哈哈哈", "哈哈哈哈"),
    ("真的假的", "真的假的呀？"),
    ("你说啥", "啊？你说啥"),
    ("困了", "我有点困了……"),
    ("收到收到", "收到收到"),
    ("哎呀", "哎呀，别闹"),
    ("牛啊", "哇，牛啊"),
    ("试音", "你好呀，我是小肥，以后用这个声音跟你说话。"),
]

SING_NAMES = ["唱两只老虎", "唱小星星", "唱生日快乐", "测试_连唱"]


def main():
    audio = gen.AUDIO_DIR
    os.makedirs(audio, exist_ok=True)
    for f in os.listdir(audio):
        if any(f.startswith(n) for n in SING_NAMES) or f.startswith("曼波"):
            p = os.path.join(audio, f)
            os.remove(p)
            print("删除", f, flush=True)

    ok, fail = 0, 0
    for name, text in LINES:
        try:
            out = gen.say(text, name)
            dur = gen.ffprobe_duration(out)
            print("OK  %-8s %5.2fs  %s" % (name, dur, text), flush=True)
            ok += 1
        except Exception as e:
            print("FAIL %-8s %s" % (name, e), flush=True)
            fail += 1
    print(f"=== 完成 {ok} 成功 / {fail} 失败 ===", flush=True)


if __name__ == "__main__":
    main()
