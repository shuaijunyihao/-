// dsh-bigfish / doctor.mjs
//
// 大肥鱼自检 + 一键修复引擎。
//
// 设计原则：
//   · 每条检查都要能说出「人话结论」和「为什么」，不只是 ok/fail
//   · 每个修复都要幂等，跑两遍不会更糟
//   · 会改文件/杀进程的修复默认要显式指名（除非 --all）
//   · 只用 Node 内置模块
//
// 用法：
//   node scripts/doctor.mjs              人类可读的体检报告
//   node scripts/doctor.mjs --json       机器可读（插件用这个）
//   node scripts/doctor.mjs --fix <id>   执行单个修复
//   node scripts/doctor.mjs --fix all    执行所有安全修复
//   node scripts/doctor.mjs --home <dir> 指定 qq-bridge 根目录
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import http from 'node:http'
import { execFileSync, spawn } from 'node:child_process'
import { fileURLToPath, pathToFileURL } from 'node:url'

const HERE = path.dirname(fileURLToPath(import.meta.url))
const PLUGIN_LIB = path.resolve(HERE, '..', 'plugins', 'dsh-bigfish', 'lib')

let D = null
try {
  // Windows 下 import() 必须是 file:// URL，直接塞 C:\... 会静默失败落回 fallback
  D = await import(pathToFileURL(path.join(PLUGIN_LIB, 'discover.js')).href)
} catch {
  D = null
}
if (!D) {
  // 插件没装时用内联的精简版，保证独立可跑
  const { createRequire } = await import('node:module')
  D = createRequire(import.meta.url)('./_discover-fallback.cjs')
}

const {
  isBridgeHome, findBridgeHome, rememberBridgeHome, findPython, findNode,
  portOpen, listeningPorts, pidOnPort, detectDshPort, readConfig,
  writeConfigBaseUrl, backupConfig, readConsoleToken, tailFile, exists, IS_WINDOWS,
} = D

const IS_WIN = IS_WINDOWS !== undefined ? IS_WINDOWS : process.platform === 'win32'
const NO_WINDOW = 0x08000000

// ---------------------------------------------------------------- 基础工具

function sh(cmd, args, opts = {}) {
  try {
    return execFileSync(cmd, args, {
      encoding: 'utf8', timeout: opts.timeout || 10000,
      windowsHide: true, ...opts,
    }).trim()
  } catch (e) {
    return (e && (e.stdout || e.message) || '').toString().trim()
  }
}

function ps(script, timeout = 12000) {
  return sh('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], { timeout })
}

function httpJson(url, { token, timeout = 2500, method = 'GET', body } = {}) {
  return new Promise((resolve) => {
    let u
    try { u = new URL(url) } catch { return resolve(null) }
    const payload = body ? JSON.stringify(body) : null
    const headers = { 'user-agent': 'dsh-bigfish-doctor' }
    if (token) headers['x-console-token'] = token
    if (payload) { headers['content-type'] = 'application/json'; headers['content-length'] = Buffer.byteLength(payload) }
    const req = http.request({
      host: u.hostname, port: u.port || 80, path: u.pathname + u.search,
      method, timeout, headers,
    }, (res) => {
      const chunks = []
      res.on('data', (c) => chunks.push(c))
      res.on('end', () => {
        const text = Buffer.concat(chunks).toString('utf8')
        let json = null
        try { json = JSON.parse(text) } catch {}
        resolve({ status: res.statusCode || 0, json, text })
      })
      res.on('error', () => resolve(null))
    })
    req.on('timeout', () => { try { req.destroy() } catch {}; resolve(null) })
    req.on('error', () => resolve(null))
    if (payload) req.write(payload)
    req.end()
  })
}

function procAlive(pid) {
  if (!pid) return false
  try { process.kill(pid, 0); return true } catch (e) { return e.code === 'EPERM' }
}

/** 按命令行子串找进程（Windows 用 CIM，其他系统用 ps）
 *  exe 可限定可执行文件名（如 'python.exe'）；不传则查所有进程。
 *  注意：守护是 python.exe，桥接是 node.exe——只查 node 会漏。 */
function findProcs(substr, exe) {
  if (!IS_WIN) {
    const out = sh('ps', ['-eo', 'pid,args'])
    return out.split('\n').filter((l) => l.includes(substr)).map((l) => {
      const m = l.trim().match(/^(\d+)\s+(.*)$/)
      return m ? { pid: Number(m[1]), cmd: m[2] } : null
    }).filter(Boolean)
  }
  const filter = exe ? `-Filter "Name='${exe}'"` : ''
  const script = `Get-CimInstance Win32_Process ${filter} -ErrorAction SilentlyContinue | ` +
    `ForEach-Object { "$($_.ProcessId)|$($_.CommandLine)" }`
  const out = ps(script, 15000)
  if (!out) return []
  return out.split(/\r?\n/).map((line) => {
    const i = line.indexOf('|')
    if (i < 0) return null
    const pid = Number(line.slice(0, i))
    const cmd = line.slice(i + 1)
    if (!Number.isFinite(pid)) return null
    return cmd.includes(substr) ? { pid, cmd } : null
  }).filter(Boolean)
}

function kill(pid) {
  try {
    if (IS_WIN) sh('taskkill.exe', ['/F', '/PID', String(pid)])
    else process.kill(pid, 'SIGKILL')
    return true
  } catch { return false }
}

/** 在沙箱外拉起进程（heredoc 走 wscript 或 detached cmd） */
function spawnDetached(exe, args, cwd) {
  try {
    const child = spawn(exe, args, {
      cwd, detached: true, stdio: 'ignore', windowsHide: true,
    })
    child.unref()
    return child.pid || true
  } catch { return false }
}

// ---------------------------------------------------------------- 上下文

async function buildCtx(homeOverride) {
  const found = findBridgeHome({ extra: homeOverride })
  const home = found.home
  const ctx = {
    home,
    tried: found.tried,
    config: home ? readConfig(home) : null,
    token: home ? readConsoleToken(home) : '',
    python: findPython(false),
    node: findNode(),
    dshPort: null,
    bridgePort: null,
    listening: [],
  }
  if (ctx.config) {
    ctx.bridgePort = Number(ctx.config.consolePort || 3100)
    const m = String(ctx.config?.dsh?.baseUrl || '').match(/:(\d+)/)
    ctx.cfgDshPort = m ? Number(m[1]) : null
  }
  ctx.listening = listeningPorts()
  const det = await detectDshPort()
  ctx.dshPort = det.port
  ctx.dshPortSource = det.from
  if (!ctx.dshPort) ctx.dshPort = ctx.cfgDshPort
  return ctx
}

// ---------------------------------------------------------------- 检查项

const CHECKS = []
const FIXES = []

function check(def) { CHECKS.push(def) }
function fix(def) { FIXES.push(def) }

// 1. 环境：能不能找到 qq-bridge
check({
  id: 'bridge-home',
  title: '定位 qq-bridge',
  why: '插件必须知道主程序在哪，否则所有操作都无从下手。',
  async run(ctx) {
    if (!ctx.home) {
      return {
        level: 'fail',
        summary: '没找到 qq-bridge',
        detail: '扫描了 ' + ctx.tried.length + ' 个候选目录都没命中。需要手动指定一次路径（面板里填）。',
        fix: null,
        manual: true,
      }
    }
    return { level: 'ok', summary: ctx.home, detail: '来自：' + (ctx.tried.find((t) => t.ok) || {}).from }
  },
})

// 2. 运行时：node / python
check({
  id: 'runtime',
  title: 'Node / Python 运行时',
  why: '桥接跑在 Node 上，后台面板和语音工具跑在 Python 上。缺一个就有一半功能是死的。',
  async run(ctx) {
    const bad = []
    if (!ctx.node) bad.push('node')
    if (!ctx.python) bad.push('python')
    if (!bad.length) {
      return {
        level: 'ok',
        summary: 'node + python 就位',
        detail: 'node: ' + ctx.node + '\npython: ' + ctx.python + '\nnode 版本: ' + process.version,
      }
    }
    return {
      level: 'fail',
      summary: '缺 ' + bad.join(' / '),
      detail: '没找到的可执行文件：' + bad.join(', ') + '。装好之后重开 DSH。',
    }
  },
})

// 3. DSH 端口漂移 —— 这是「大肥鱼突然不说话了」的头号原因
check({
  id: 'dsh-port',
  title: 'DSH 端口与配置是否一致',
  why: 'DSH 每次重启都会换一个随机 web 端口。config.json 里写死的那一个一旦过期，桥接就会一直连、一直 0 帧、永远连不回来——消息全部进队列，看起来就是「她死了」。',
  async run(ctx) {
    if (!ctx.config) return { level: 'skip', summary: '无配置可查' }
    const cfg = ctx.cfgDshPort
    const actual = ctx.dshPort
    if (!cfg) return { level: 'warn', summary: 'config 里没有 baseUrl', detail: 'dsh.baseUrl 缺失。', fix: 'fix-baseurl' }
    if (!actual) return { level: 'warn', summary: '没探测到 DSH 端口', detail: 'DSH 可能没在跑，或本进程不在 DSH 里面。config 指向 ' + cfg + '.' }
    if (cfg === actual) {
      return { level: 'ok', summary: cfg, detail: 'config 与实际一致（来源: ' + ctx.dshPortSource + '）' }
    }
    return {
      level: 'fail',
      summary: 'config=' + cfg + '，实际=' + actual,
      detail: '桥接连的是 ' + cfg + '，但 DSH 在 ' + actual + '。她会一直重连失败。',
      fix: 'fix-baseurl',
    }
  },
})

// 4. 过期锁
check({
  id: 'stale-lock',
  title: '桥接锁文件',
  why: 'state/bridge.lock 里存着一个已经死掉的 PID 时，新进程会以为「已经有一个在跑」直接退出，日志只留一句 already running。',
  async run(ctx) {
    if (!ctx.home) return { level: 'skip', summary: '无主程序目录' }
    const lock = path.join(ctx.home, 'state', 'bridge.lock')
    if (!exists(lock)) return { level: 'ok', summary: '无锁文件' }
    let pid = null
    try { pid = Number(fs.readFileSync(lock, 'utf8').trim()) } catch {}
    if (!pid) return { level: 'warn', summary: '锁文件内容不可读', fix: 'kill-stale-lock' }
    if (procAlive(pid)) {
      return { level: 'ok', summary: 'PID ' + pid + ' 活着', detail: '锁正确，不是残留。' }
    }
    return {
      level: 'fail',
      summary: '残留死 PID ' + pid,
      detail: '这个进程早就没了，但锁还在。新桥接会被挡在门外。',
      fix: 'kill-stale-lock',
    }
  },
})

// 5. 桥接进程在不在
check({
  id: 'bridge-running',
  title: '桥接进程',
  why: 'src/bridge.js 是整条链路的中枢，它不在，QQ 那边就完全没有回应。',
  async run(ctx) {
    if (!ctx.home) return { level: 'skip', summary: '无主程序目录' }
    const port = ctx.bridgePort || 3100
    const pid = pidOnPort(port)
    const procs = findProcs('bridge.js')
    if (pid || procs.length) {
      return {
        level: 'ok',
        summary: '监听 ' + port + '（PID ' + (pid || procs[0].pid) + '）',
        detail: procs.map((p) => p.pid + '  ' + p.cmd).join('\n') || ('端口 ' + port + ' 有监听'),
      }
    }
    return {
      level: 'fail',
      summary: '没在跑',
      detail: '端口 ' + port + ' 没有监听，也没有找到 bridge.js 进程。',
      fix: 'start-bridge',
    }
  },
})

// 6. 桥接控制台是否健康
check({
  id: 'bridge-status',
  title: '桥接控制台 / DSH 连接',
  why: '桥接活着不代表它连上了 DSH。dshReady=false 时她会收消息但不会回。mode 必须是 reserved2，chat 模式下所有发送工具是关闭的。',
  async run(ctx) {
    if (!ctx.home) return { level: 'skip', summary: '无主程序目录' }
    const port = ctx.bridgePort || 3100
    const r = await httpJson('http://127.0.0.1:' + port + '/api/status', { token: ctx.token })
    if (!r || !r.json) {
      return { level: 'fail', summary: '控制台无响应', detail: '127.0.0.1:' + port + '/api/status 没有返回 JSON。', fix: 'start-bridge' }
    }
    const s = r.json
    const issues = []
    if (s.dshReady !== true) issues.push('dshReady=false')
    if (s.mode && s.mode !== 'reserved2') issues.push('mode=' + s.mode)
    if (s.snowluma && s.snowluma.connected === false) issues.push('SnowLuma 未连接')
    if (s.snowluma && s.snowluma.accountOnline === false) issues.push('QQ 账号离线')
    if (s.socialV2Paused) issues.push('主动聊天已暂停')

    const lines = [
      'mode=' + s.mode + '  dshReady=' + s.dshReady,
      'role=' + s.role + '（' + s.roleMode + '）',
      'snowluma.connected=' + (s.snowluma && s.snowluma.connected),
      'accountOnline=' + (s.snowluma && s.snowluma.accountOnline),
      'ownerQQ=' + s.ownerQQ,
    ]
    if (issues.length) {
      const onlyMode = issues.length === 1 && String(issues[0]).startsWith('mode=')
      return {
        level: onlyMode ? 'warn' : 'fail',
        summary: issues.join('；'),
        detail: lines.join('\n'),
        fix: onlyMode ? 'fix-mode' : (s.dshReady !== true ? 'fix-baseurl' : null),
      }
    }
    return { level: 'ok', summary: '已就绪', detail: lines.join('\n') }
  },
})

// 7. SnowLuma 网关
check({
  id: 'gateway',
  title: 'SnowLuma 网关',
  why: '网关是 QQ 协议的唯一出入口。它假死时桥接连得上但一帧数据都收不到，症状跟「DSH 断了」几乎一样。',
  async run(ctx) {
    const ws = await portOpen(3001)
    const ht = await portOpen(3000)
    const procs = findProcs('SnowLuma')
    if (ws && ht) {
      return {
        level: 'ok',
        summary: '3000 / 3001 在听',
        detail: procs.map((p) => 'PID ' + p.pid).join(' ') || '端口正常',
      }
    }
    return {
      level: 'fail',
      summary: !ws && !ht ? '两个端口都没了' : (ws ? 'HTTP 3000 未监听' : 'WS 3001 未监听'),
      detail: '进程数：' + procs.length + '。网关假死或没启动。',
      fix: 'restart-gateway',
    }
  },
})

// 8. 网关守护
check({
  id: 'gateway-guard',
  title: '网关守护进程',
  why: 'snowluma-guard.py 负责在网关假死时自动重启它。它自己用 pythonw 拉起会静默失败——进程没跑、日志不动、看起来一切正常，这是整套系统里最阴的一类故障。',
  async run(ctx) {
    const procs = findProcs('snowluma-guard', 'python.exe')
    if (procs.length) {
      const log = tailFile('C:\\SnowLuma\\snowluma-guard.log', 3)
      return { level: 'ok', summary: 'PID ' + procs[0].pid, detail: log.join('\n') || '（无日志）' }
    }
    const script = 'C:\\SnowLuma\\snowluma-guard.py'
    if (!exists(script)) return { level: 'skip', summary: '没有守护脚本' }
    return {
      level: 'warn',
      summary: '没在运行',
      detail: '网关假死时没人救它。守护脚本存在但进程不在。',
      fix: 'start-guard',
    }
  },
})

// 9. 端口同步守护
check({
  id: 'port-sync',
  title: '端口同步守护',
  why: '这是给端口漂移打的补丁。它在跑，「DSH 换端口导致她失联」就自动恢复；它不在，下次 DSH 重启又要人工救一次。',
  async run(ctx) {
    if (!ctx.home) return { level: 'skip', summary: '无主程序目录' }
    const script = path.join(ctx.home, 'scripts', 'dsh-port-sync.mjs')
    if (!exists(script)) {
      return { level: 'warn', summary: '脚本不存在', detail: 'scripts/dsh-port-sync.mjs 缺失，需要同步一份过去。', fix: 'install-port-sync' }
    }
    const procs = findProcs('dsh-port-sync')
    if (procs.length) {
      return { level: 'ok', summary: 'PID ' + procs[0].pid, detail: procs[0].cmd }
    }
    return { level: 'warn', summary: '没在跑', detail: 'DSH 下次换端口时没人改写 config。', fix: 'start-port-sync' }
  },
})

// 10. 会话卡死
check({
  id: 'session-stuck',
  title: '会话是否卡在「繁忙」',
  why: '翻唱/长任务超时后回合不释放，之后所有消息只排队永不回复。这时看日志一切正常，只有 session reset 能救。',
  async run(ctx) {
    if (!ctx.home) return { level: 'skip', summary: '无主程序目录' }
    const log = tailFile(path.join(ctx.home, 'state', 'bridge.log'), 200)
    if (!log.length) return { level: 'skip', summary: '无日志' }
    const joined = log.join('\n')
    const busy = /回合超时|still busy|会话繁忙.*超时/.test(joined)
    const lastMs = fs.statSync(path.join(ctx.home, 'state', 'bridge.log')).mtimeMs
    const idleMin = (Date.now() - lastMs) / 60000
    if (busy && idleMin > 5) {
      return {
        level: 'warn',
        summary: '疑似卡死（日志 ' + idleMin.toFixed(0) + ' 分钟没动）',
        detail: '尾部日志：\n' + log.slice(-6).join('\n'),
        fix: 'reset-session',
      }
    }
    return { level: 'ok', summary: '正常', detail: '日志 ' + idleMin.toFixed(0) + ' 分钟前有更新' }
  },
})

// 11. 日志里的已知错误指纹
const SIGNATURES = [
  { re: /spawnSync \w+ EPERM/, label: '沙箱 EPERM', why: '在 DSH 沙箱里 spawn 的进程会被拒绝（netstat/icacls EPERM）。桥接会误判端口占用然后 exit(2)。必须在沙箱外启动。' },
  { re: /bridge already running/i, label: '重复实例', why: '锁文件残留或真的起了两份。' },
  { re: /Could not load symbol cudnnGetLibConfig/, label: 'cudnn 冲突', why: 'faster_whisper 与 torch 同进程。ASR 必须单独进程跑。' },
  { re: /Illegal byte sequence/, label: 'ffmpeg 中文路径', why: 'ffmpeg 遇到中文路径会崩。先把文件复制到英文临时路径。' },
  { re: /ENOTFOUND|ETIMEDOUT.*github/i, label: 'GitHub 直连不通', why: '元数据走 api.github.com，包体走 gh-proxy.org，HF 走 hf-mirror.com。' },
  { re: /一帧都没收到/, label: '事件流空转', why: 'DSH 端口不对，或 DSH 侧协议不匹配。先查 baseUrl。' },
]

check({
  id: 'log-signatures',
  title: '日志已知错误指纹',
  why: '很多故障不会自己报错，只会在日志里留一句看不懂的话。',
  async run(ctx) {
    if (!ctx.home) return { level: 'skip', summary: '无主程序目录' }
    const files = ['bridge.log', 'dsh-port-sync.log', 'launcher.log']
    const hits = []
    for (const f of files) {
      const p = path.join(ctx.home, 'state', f)
      const lines = tailFile(p, 400)
      if (!lines.length) continue
      // 只看本次进程活着之后的日志：找最后一条启动标记，从那之后扫。
      // 否则上一次崩溃留下的旧行会一直被报出来，永远消不掉。
      let from = 0
      for (let i = lines.length - 1; i >= 0; i--) {
        if (/自愈完成：账号|DSH 已就绪|端口同步守护启动/.test(lines[i])) { from = i; break }
      }
      const scope = lines.slice(from)
      for (const s of SIGNATURES) {
        const line = scope.find((l) => s.re.test(l))
        if (line) hits.push({ file: f, sig: s, line: line.slice(0, 200) })
      }
    }
    if (!hits.length) return { level: 'ok', summary: '没命中已知指纹' }
    const html = hits.map((h) => '[' + h.sig.label + '] ' + h.file + '\n  ' + h.line + '\n  → ' + h.sig.why).join('\n')
    return {
      level: 'warn',
      summary: hits.length + ' 处命中：' + [...new Set(hits.map((h) => h.sig.label))].join('、'),
      detail: html,
    }
  },
})

// 12. 写权限（state 目录 ACL）
check({
  id: 'state-writable',
  title: 'state 目录可写',
  why: 'state/ 被 ACL 收得很紧（只有 SYSTEM/Administrators）。别的账户跑就写不进锁、日志、令牌，表现为各种莫名其妙的「拒绝访问」。',
  async run(ctx) {
    if (!ctx.home) return { level: 'skip', summary: '无主程序目录' }
    const dir = path.join(ctx.home, 'state')
    if (!exists(dir)) return { level: 'warn', summary: 'state 目录不存在' }
    const probe = path.join(dir, '.doctor-probe-' + process.pid)
    try {
      fs.writeFileSync(probe, 'ok')
      fs.unlinkSync(probe)
      return { level: 'ok', summary: '可写' }
    } catch (e) {
      return { level: 'fail', summary: '写不进去', detail: e.message, fix: 'fix-state-acl' }
    }
  },
})

// 13. 开机自启
check({
  id: 'autostart',
  title: '开机自启链',
  why: '重启电脑后没人把桥接和网关拉起来，她就会一直「死」到你手动开一次。',
  async run(ctx) {
    if (!ctx.home || !IS_WIN) return { level: 'skip', summary: '非 Windows 或未定位主程序' }
    const dir = path.join(os.homedir(), 'AppData', 'Roaming', 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup')
    const want = ['qq-bridge-autostart.vbs', 'snowluma-autostart.vbs', 'snowluma-guard.vbs']
    const missing = want.filter((f) => !exists(path.join(dir, f)))
    const broken = []
    for (const f of want) {
      const p = path.join(dir, f)
      if (!exists(p)) continue
      let txt = ''
      try { txt = fs.readFileSync(p, 'latin1') } catch { continue }
      if (/pythonw\.exe/i.test(txt) && f.includes('guard')) broken.push(f + '（用 pythonw 会静默失败）')
    }
    if (missing.length || broken.length) {
      return {
        level: 'warn',
        summary: [missing.length ? '缺 ' + missing.length + ' 项' : '', broken.length ? broken.length + ' 项有问题' : ''].filter(Boolean).join('，'),
        detail: '缺失：' + (missing.join(', ') || '无') + '\n问题：' + (broken.join(', ') || '无'),
        fix: 'repair-autostart',
      }
    }
    return { level: 'ok', summary: want.length + ' 项齐全' }
  },
})

// 14. start.bat 健康
check({
  id: 'start-bat',
  title: 'start.bat 是否会在隐藏窗口里挂死',
  why: '老版本 start.bat 在退出码 2 时调用 pause 再 exit。start-hidden.cmd 是隐藏窗口，pause 等于永久阻塞——守护循环整个死掉，不留一行日志。',
  async run(ctx) {
    if (!ctx.home) return { level: 'skip', summary: '无主程序目录' }
    const p = path.join(ctx.home, 'start.bat')
    if (!exists(p)) return { level: 'warn', summary: '没有 start.bat' }
    const raw = fs.readFileSync(p, 'utf8')
    const hasPause = /^\s*pause\b/im.test(raw)
    const crlf = raw.includes('\r\n')
    const hasSync = raw.includes('dsh-port-sync')
    const issues = []
    if (hasPause) issues.push('含 pause（隐藏窗口会挂死）')
    if (hasSync) issues.push('已包含端口同步')  // 提示，不算问题
    if (issues.length === 1 && issues[0] === '已包含端口同步') {
      return { level: 'ok', summary: '健康（含端口同步）' }
    }
    if (hasPause) {
      return { level: 'fail', summary: '含 pause', detail: issues.join('\n'), fix: 'fix-start-bat' }
    }
    if (!hasSync) {
      return { level: 'warn', summary: '没接入端口同步', detail: 'DSH 换端口后不会自动恢复。', fix: 'install-port-sync' }
    }
    return { level: 'ok', summary: '健康', detail: 'CRLF=' + crlf }
  },
})

// ---------------------------------------------------------------- 修复项

fix({
  id: 'fix-baseurl',
  title: '把 config.json 的 baseUrl 改成实际 DSH 端口',
  safe: true,
  async apply(ctx) {
    if (!ctx.home) return { ok: false, error: '没定位到 qq-bridge' }
    if (!ctx.dshPort) return { ok: false, error: '没探测到 DSH 端口' }
    const bak = backupConfig(ctx.home, 'doctor')
    const r = writeConfigBaseUrl(ctx.home, ctx.dshPort)
    if (!r.ok) return r
    // 改完要重启桥接才生效
    const restarted = await restartBridge(ctx)
    return {
      ok: true,
      detail: (r.changed ? '已改写 baseUrl → ' + ctx.dshPort : '本来就是 ' + ctx.dshPort) +
        (bak ? '\n备份：' + path.basename(bak) : '') +
        '\n桥接重启：' + (restarted.ok ? '已请求' : '失败（' + restarted.error + '）'),
    }
  },
})

fix({
  id: 'kill-stale-lock',
  title: '删掉残留的桥接锁',
  safe: true,
  async apply(ctx) {
    if (!ctx.home) return { ok: false, error: '没定位到 qq-bridge' }
    const lock = path.join(ctx.home, 'state', 'bridge.lock')
    if (!exists(lock)) return { ok: true, detail: '没有锁文件，无需处理' }
    let pid = 0
    try { pid = Number(fs.readFileSync(lock, 'utf8').trim()) } catch {}
    if (pid && procAlive(pid)) {
      return { ok: false, error: 'PID ' + pid + ' 还活着，这不是残留锁，不该删' }
    }
    try {
      fs.unlinkSync(lock)
      return { ok: true, detail: '已删除（原 PID ' + (pid || '?') + '）' }
    } catch (e) { return { ok: false, error: e.message } }
  },
})

fix({
  id: 'start-bridge',
  title: '启动桥接（沙箱外）',
  safe: true,
  async apply(ctx) {
    if (!ctx.home) return { ok: false, error: '没定位到 qq-bridge' }
    // 先清残留锁
    const lock = path.join(ctx.home, 'state', 'bridge.lock')
    if (exists(lock)) {
      let pid = 0
      try { pid = Number(fs.readFileSync(lock, 'utf8').trim()) } catch {}
      if (!pid || !procAlive(pid)) { try { fs.unlinkSync(lock) } catch {} }
    }
    const runner = path.join(ctx.home, 'start-hidden.vbs')
    if (exists(runner) && IS_WIN) {
      const r = spawnDetached('wscript.exe', ['"' + runner + '"'], ctx.home)
      if (!r) return { ok: false, error: '拉起 start-hidden.vbs 失败' }
    } else {
      const node = ctx.node
      if (!node) return { ok: false, error: '找不到 node' }
      const r = spawnDetached(node, [path.join(ctx.home, 'src', 'bridge.js')], ctx.home)
      if (!r) return { ok: false, error: '拉起 node 失败' }
    }
    // 等它起来
    const port = ctx.bridgePort || 3100
    for (let i = 0; i < 24; i++) {
      await new Promise((r) => setTimeout(r, 500))
      if (await portOpen(port)) {
        return { ok: true, detail: '端口 ' + port + ' 已监听（等待 ' + ((i + 1) * 0.5).toFixed(1) + 's）' }
      }
    }
    return { ok: false, error: '已拉起但 12 秒内端口 ' + port + ' 没起来，看 state/bridge.log' }
  },
})

fix({
  id: 'restart-gateway',
  title: '重启 SnowLuma 网关',
  safe: false,
  async apply(ctx) {
    const procs = findProcs('SnowLuma')
    for (const p of procs) kill(p.pid)
    await new Promise((r) => setTimeout(r, 1500))
    const root = 'C:\\SnowLuma\\SnowLuma-v2.1.1-win-x64'
    if (!exists(root)) return { ok: false, error: 'SnowLuma 目录不存在：' + root }
    const node = path.join(root, 'node.exe')
    const exe = exists(node) ? node : ctx.node
    if (!exe) return { ok: false, error: '找不到 node' }
    spawnDetached(exe, ['index.mjs'], root)
    for (let i = 0; i < 30; i++) {
      await new Promise((r) => setTimeout(r, 700))
      if (await portOpen(3000) && await portOpen(3001)) {
        return { ok: true, detail: '3000/3001 已恢复（' + ((i + 1) * 0.7).toFixed(1) + 's）' }
      }
    }
    return { ok: false, error: '拉起了但端口没恢复，检查 SnowLuma 日志' }
  },
})

fix({
  id: 'start-guard',
  title: '启动网关守护',
  safe: true,
  async apply(ctx) {
    const script = 'C:\\SnowLuma\\snowluma-guard.py'
    if (!exists(script)) return { ok: false, error: '没有 snowluma-guard.py' }
    const py = findPython(true) || ctx.python
    if (!py) return { ok: false, error: '找不到 python（注意：必须用 python.exe，pythonw 会静默失败）' }
    spawnDetached(py, [script], path.dirname(script))
    await new Promise((r) => setTimeout(r, 1200))
    const procs = findProcs('snowluma-guard', 'python.exe')
    if (procs.length) return { ok: true, detail: 'PID ' + procs[0].pid }
    return { ok: false, error: '拉起了但进程不在，可能脚本报错' }
  },
})

fix({
  id: 'install-port-sync',
  title: '安装并接入端口同步守护',
  safe: true,
  async apply(ctx) {
    if (!ctx.home) return { ok: false, error: '没定位到 qq-bridge' }
    const dst = path.join(ctx.home, 'scripts', 'dsh-port-sync.mjs')
    if (!exists(dst)) {
      return { ok: false, error: 'scripts/dsh-port-sync.mjs 不存在，需要先把脚本放到 ' + dst }
    }
    // 接入 start.bat
    const bat = path.join(ctx.home, 'start.bat')
    let note = ''
    if (exists(bat)) {
      const raw = fs.readFileSync(bat, 'utf8')
      if (!raw.includes('dsh-port-sync')) {
        const idx = raw.indexOf(':loop')
        if (idx >= 0) {
          const inject = 'rem --- DSH port sync guard ---\r\nstart "" /b node scripts\\dsh-port-sync.mjs --watch\r\n'
          fs.writeFileSync(bat, raw.slice(0, idx) + inject + raw.slice(idx), 'utf8')
          note = '\n已接入 start.bat'
        }
      } else note = '\nstart.bat 里已有'
    }
    // 立刻起一个
    spawnDetached(ctx.node, [dst, '--watch'], ctx.home)
    await new Promise((r) => setTimeout(r, 1200))
    const procs = findProcs('dsh-port-sync')
    return {
      ok: procs.length > 0,
      detail: (procs.length ? '已启动 PID ' + procs[0].pid : '拉起失败') + note,
      error: procs.length ? undefined : '进程没起来',
    }
  },
})

fix({
  id: 'start-port-sync',
  title: '启动端口同步守护',
  safe: true,
  async apply(ctx) {
    if (!ctx.home) return { ok: false, error: '没定位到 qq-bridge' }
    const script = path.join(ctx.home, 'scripts', 'dsh-port-sync.mjs')
    if (!exists(script)) return { ok: false, error: '脚本不存在，先跑 install-port-sync' }
    if (!ctx.node) return { ok: false, error: '找不到 node' }
    spawnDetached(ctx.node, [script, '--watch'], ctx.home)
    await new Promise((r) => setTimeout(r, 1200))
    const procs = findProcs('dsh-port-sync')
    return procs.length
      ? { ok: true, detail: 'PID ' + procs[0].pid }
      : { ok: false, error: '拉起了但进程不在' }
  },
})

fix({
  id: 'fix-mode',
  title: '把模式切回 reserved2',
  safe: true,
  async apply(ctx) {
    if (!ctx.home) return { ok: false, error: '没定位到 qq-bridge' }
    const port = ctx.bridgePort || 3100
    const r = await httpJson('http://127.0.0.1:' + port + '/api/mode', {
      token: ctx.token, method: 'POST', body: { mode: 'reserved2' },
    })
    if (!r) return { ok: false, error: '桥接控制台无响应' }
    if (r.status === 200) return { ok: true, detail: '已切到 reserved2' }
    return { ok: false, error: 'HTTP ' + r.status + ' ' + (r.text || '').slice(0, 120) }
  },
})

fix({
  id: 'reset-session',
  title: '重置卡死的会话',
  safe: false,
  async apply(ctx) {
    if (!ctx.home) return { ok: false, error: '没定位到 qq-bridge' }
    const port = ctx.bridgePort || 3100
    // 先问桥接当前有哪些会话 key
    const st = await httpJson('http://127.0.0.1:' + port + '/api/status', { token: ctx.token })
    const keys = new Set()
    const act = (st && st.json && st.json.activity) || ''
    for (const m of String(act).matchAll(/(group:\d+|private:\d+)/g)) keys.add(m[1])
    if (!keys.size) keys.add('private:' + (ctx.config?.ownerQQ || ''))
    const results = []
    for (const key of keys) {
      const r = await httpJson('http://127.0.0.1:' + port + '/api/session/reset', {
        token: ctx.token, method: 'POST', body: { key },
      })
      results.push(key + ': ' + (r ? r.status : '无响应'))
    }
    return { ok: true, detail: results.join('\n') }
  },
})

fix({
  id: 'fix-state-acl',
  title: '修复 state 目录权限',
  safe: false,
  async apply(ctx) {
    if (!ctx.home) return { ok: false, error: '没定位到 qq-bridge' }
    const dir = path.join(ctx.home, 'state')
    const user = process.env.USERNAME || os.userInfo().username
    const out1 = sh('icacls.exe', [dir, '/grant', user + ':(OI)(CI)F', '/T', '/C'])
    return { ok: /已处理|processed/i.test(out1), detail: out1.slice(0, 400) || 'icacls 无输出' }
  },
})

fix({
  id: 'repair-autostart',
  title: '重建开机自启项',
  safe: false,
  async apply(ctx) {
    if (!ctx.home) return { ok: false, error: '没定位到 qq-bridge' }
    if (!IS_WIN) return { ok: false, error: '仅 Windows' }
    const dir = path.join(os.homedir(), 'AppData', 'Roaming', 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup')
    fs.mkdirSync(dir, { recursive: true })
    const done = []
    const bridgeVbs = [
      'Set sh = CreateObject("WScript.Shell")',
      'sh.Run "wscript.exe ""' + path.join(ctx.home, 'start-hidden.vbs') + '""", 0, False',
    ].join('\r\n')
    try {
      fs.writeFileSync(path.join(dir, 'qq-bridge-autostart.vbs'), bridgeVbs, 'latin1')
      done.push('qq-bridge-autostart.vbs')
    } catch (e) { done.push('bridge 写入失败: ' + e.message) }

    const slRoot = 'C:\\SnowLuma\\SnowLuma-v2.1.1-win-x64'
    if (exists(slRoot)) {
      const slVbs = [
        'Set sh = CreateObject("WScript.Shell")',
        'sh.CurrentDirectory = "' + slRoot + '"',
        'sh.Run "' + path.join(slRoot, 'node.exe') + ' index.mjs", 0, False',
      ].join('\r\n')
      try {
        fs.writeFileSync(path.join(dir, 'snowluma-autostart.vbs'), slVbs, 'latin1')
        done.push('snowluma-autostart.vbs')
      } catch (e) { done.push('snowluma 写入失败: ' + e.message) }

      const py = findPython(true) || ctx.python
      if (py && exists('C:\\SnowLuma\\snowluma-guard.py')) {
        const gVbs = [
          'Set sh = CreateObject("WScript.Shell")',
          'sh.Run "' + py + ' ""C:\\SnowLuma\\snowluma-guard.py""", 0, False',
        ].join('\r\n')
        try {
          fs.writeFileSync(path.join(dir, 'snowluma-guard.vbs'), gVbs, 'latin1')
          done.push('snowluma-guard.vbs')
        } catch (e) { done.push('guard 写入失败: ' + e.message) }
      }
    }
    return { ok: true, detail: '已写入：\n' + done.join('\n') }
  },
})

fix({
  id: 'fix-start-bat',
  title: '把 start.bat 里会挂死的 pause 换掉',
  safe: false,
  async apply(ctx) {
    if (!ctx.home) return { ok: false, error: '没定位到 qq-bridge' }
    const p = path.join(ctx.home, 'start.bat')
    if (!exists(p)) return { ok: false, error: '没有 start.bat' }
    let raw = fs.readFileSync(p, 'utf8')
    try { fs.copyFileSync(p, p + '.bak-doctor-' + Date.now()) } catch {}
    // 干掉 pause 行，并把 exit /b 2 换成重试
    raw = raw.replace(/^\s*pause\s*\r?\n/gim, '')
    raw = raw.replace(/exit\s*\/b\s*2/gim, 'timeout /t 30 /nobreak >nul\r\ngoto loop')
    fs.writeFileSync(p, raw, 'utf8')
    return { ok: true, detail: '已移除 pause、退出码 2 改为 30 秒后重试（原文件已备份）' }
  },
})

// ---------------------------------------------------------------- 执行

async function runChecks(ctx) {
  const out = []
  for (const c of CHECKS) {
    const t0 = Date.now()
    let res
    try {
      res = await c.run(ctx)
    } catch (e) {
      res = { level: 'error', summary: '检查出错', detail: e && e.stack || String(e) }
    }
    out.push({
      id: c.id,
      title: c.title,
      why: c.why,
      level: res.level || 'ok',
      summary: res.summary || '',
      detail: res.detail || '',
      fix: res.fix || null,
      manual: !!res.manual,
      ms: Date.now() - t0,
    })
  }
  return out
}

function summarize(results) {
  const count = (lv) => results.filter((r) => r.level === lv).length
  const fails = count('fail')
  const warns = count('warn')
  const level = fails ? 'fail' : warns ? 'warn' : 'ok'
  const verdict = fails
    ? (fails + ' 项故障' + (warns ? '、' + warns + ' 项警告' : '') + '，她大概不会正常回话')
    : warns
      ? (warns + ' 项警告，目前能用但要留意')
      : '全部正常'
  return { level, verdict, fails, warns, oks: count('ok'), skips: count('skip'), errors: count('error') }
}

async function main() {
  const argv = process.argv.slice(2)
  const json = argv.includes('--json')
  const homeArg = (() => {
    const i = argv.indexOf('--home')
    return i >= 0 ? argv[i + 1] : null
  })()
  const fixIdx = argv.indexOf('--fix')
  const fixTarget = fixIdx >= 0 ? argv[fixIdx + 1] : null
  const listFixes = argv.includes('--list-fixes')

  if (listFixes) {
    for (const f of FIXES) console.log(f.id + '\t' + (f.safe ? 'safe' : 'risky') + '\t' + f.title)
    return
  }

  const ctx = await buildCtx(homeArg)

  if (fixTarget) {
    const targets = fixTarget === 'all'
      ? FIXES.filter((f) => f.safe)
      : FIXES.filter((f) => f.id === fixTarget)
    if (!targets.length) {
      const out = { ok: false, error: '未知修复: ' + fixTarget }
      console.log(json ? JSON.stringify(out) : out.error)
      process.exitCode = 1
      return
    }
    const results = []
    for (const f of targets) {
      let r
      try { r = await f.apply(ctx) } catch (e) { r = { ok: false, error: e && e.message || String(e) } }
      results.push({ id: f.id, title: f.title, ok: !!r.ok, detail: r.detail || '', error: r.error || '' })
    }
    if (json) console.log(JSON.stringify({ ok: results.every((r) => r.ok), results }, null, 2))
    else results.forEach((r) => console.log((r.ok ? '✓' : '✗') + ' ' + r.title + (r.detail ? '\n  ' + r.detail.replace(/\n/g, '\n  ') : '') + (r.error ? '\n  ✗ ' + r.error : '')))
    process.exitCode = results.every((r) => r.ok) ? 0 : 1
    return
  }

  const results = await runChecks(ctx)
  const sum = summarize(results)
  const payload = {
    ok: sum.level === 'ok',
    verdict: sum.verdict,
    level: sum.level,
    counts: sum,
    home: ctx.home,
    tried: ctx.tried,
    dshPort: ctx.dshPort,
    dshPortSource: ctx.dshPortSource,
    configDshPort: ctx.cfgDshPort,
    bridgePort: ctx.bridgePort,
    node: ctx.node,
    python: ctx.python,
    platform: process.platform,
    nodeRuntime: process.version,
    now: new Date().toISOString(),
    checks: results,
    fixes: FIXES.map((f) => ({ id: f.id, title: f.title, safe: f.safe })),
  }
  if (json) console.log(JSON.stringify(payload, null, 2))
  else {
    console.log('')
    console.log('  大肥鱼体检  ·  ' + new Date().toLocaleString('zh-CN'))
    console.log('  ' + '-'.repeat(56))
    console.log('  结论：' + sum.verdict)
    if (ctx.home) console.log('  主程序：' + ctx.home)
    console.log('')
    const icon = { ok: '✓', warn: '!', fail: '✗', skip: '·', error: '?' }
    for (const r of results) {
      console.log('  ' + (icon[r.level] || '·') + ' ' + r.title + '：' + r.summary)
      if (r.detail && (r.level === 'fail' || r.level === 'warn')) {
        console.log('    ' + r.detail.replace(/\n/g, '\n    '))
      }
    }
    console.log('')
    const fixable = results.filter((r) => r.fix)
    if (fixable.length) {
      console.log('  可以一键修：')
      for (const r of fixable) console.log('    · ' + r.fix + '  ←  ' + r.title)
      console.log('')
      console.log('  node scripts/doctor.mjs --fix all   （只跑安全项）')
    }
    console.log('')
  }
  process.exitCode = sum.level === 'ok' ? 0 : sum.level === 'warn' ? 0 : 1
}

main()
