#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""F5-TTS 音色克隆后端：把任意文本合成成“曼波”音色的语音。

模型只在进程内加载一次；输出 24kHz 单声道 wav。
"""
import os
import threading

os.environ.setdefault("HF_ENDPOINT", "https://hf-mirror.com")
os.environ.setdefault("HF_HUB_DISABLE_XET", "1")

import numpy as np
import torch
import torchaudio

HERE = os.path.dirname(os.path.abspath(__file__))
# 参考音色：默认用第一轮克隆出来、已经验证干净的那句（比带伴奏的原片段稳定得多）
REF_AUDIO = os.environ.get("F5_REF_AUDIO") or os.path.join(HERE, "ref", "xinyu_ref.wav")
REF_TEXT = os.environ.get("F5_REF_TEXT") or "好嘛，这条发完就先歇会儿啦。收到了，这样听着清楚吗？"

_lock = threading.Lock()
_model = None


def _get_model():
    global _model
    if _model is None:
        from f5_tts.api import F5TTS

        device = "cuda" if torch.cuda.is_available() else "cpu"
        _model = F5TTS(model="F5TTS_v1_Base", device=device)
    return _model


def synth(text, out_wav, speed=1.0, seed=1234):
    """把 text 用曼波音色合成到 out_wav（24kHz 单声道 float wav）"""
    text = (text or "").strip()
    if not text:
        raise ValueError("文本为空")
    out_wav = os.path.abspath(out_wav)
    os.makedirs(os.path.dirname(out_wav), exist_ok=True)
    with _lock:
        model = _get_model()
        torch.manual_seed(seed)
        wav, sr, _ = model.infer(
            ref_file=REF_AUDIO,
            ref_text=REF_TEXT,
            gen_text=text,
            speed=speed,
            show_info=lambda *a, **k: None,
        )
        arr = np.asarray(wav)
        if arr.ndim == 1:
            arr = arr[None, :]
        torchaudio.save(out_wav, torch.from_numpy(arr.astype("float32")).cpu(), sr)
    return out_wav


if __name__ == "__main__":
    import sys

    text = sys.argv[1] if len(sys.argv) > 1 else "你好呀，我是小肥。"
    out = sys.argv[2] if len(sys.argv) > 2 else os.path.join(HERE, "out", "cli.wav")
    print(synth(text, out))
