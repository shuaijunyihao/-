﻿$tok = (Get-Content "C:\Users\Administrator\Documents\deepseek-harness\default-workspace\qq-bridge-main\state\console-token" -Raw).Trim()
$url = "http://127.0.0.1:3100/?token=" + $tok
$edge = "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
$desktop = [Environment]::GetFolderPath("Desktop")
$lnk = Join-Path $desktop "QQ后台.lnk"
$ws = New-Object -ComObject WScript.Shell
$sc = $ws.CreateShortcut($lnk)
$sc.TargetPath = $edge
$sc.Arguments = $url
$sc.WorkingDirectory = "C:\Program Files (x86)\Microsoft\Edge\Application"
$sc.Description = "QQ bridge console"
$sc.Save()
Write-Output ("created=" + $lnk)
