' 静默启动 qq-bridge —— 给「启动」文件夹 / 任务计划用的无窗口启动器。
' 实际入口是同目录的 start-hidden.cmd（负责补 PATH）→ start.bat（负责崩溃重启循环）。
Option Explicit

Dim fso, sh, here, entry, logFile

Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")

here = fso.GetParentFolderName(WScript.ScriptFullName)
entry = fso.BuildPath(here, "start-hidden.cmd")
logFile = fso.BuildPath(here, "state\launcher.log")

Sub LogLine(msg)
  On Error Resume Next
  Dim f
  Set f = fso.OpenTextFile(logFile, 8, True)
  f.WriteLine Now & "  " & msg
  f.Close
End Sub

LogLine "launcher start"

If Not fso.FileExists(entry) Then
  LogLine "ERROR: start-hidden.cmd not found at " & entry
  WScript.Quit 1
End If

sh.CurrentDirectory = here
On Error Resume Next
sh.Run "cmd.exe /c """ & entry & """", 0, False
If Err.Number <> 0 Then
  LogLine "ERROR: Run failed: " & Err.Number & " " & Err.Description
  Err.Clear
Else
  LogLine "spawned start-hidden.cmd"
End If
