import io

P = r"C:\Users\Administrator\Documents\deepseek-harness\default-workspace\qq-bridge-main\src\bridge.js"
src = io.open(P, encoding="utf-8").read()

# ── 1) 看门狗实现：插在 isConversationBusyV2() 之后 ──────────────────────────
anchor = """    if (collector && !turnLeaseNoted.has(sid)) {
      turnLeaseNoted.add(sid);
      log(`[reserved2] 回合判忙租约已过期（${sid}，起始 ${Math.round((Date.now() - startedAt) / 60000)} 分钟前），解除忙碌；collector 保留，迟到回复仍会 flush`);
    }
    return false;
  }
"""
assert anchor in src, "锚点未找到"

watchdog = anchor + """
  // ── 回合超时看门狗（防“聊着聊着人没了”） ────────────────────────────────
  // 为什么必须要有：DSH 的 turn 一旦卡在某个外部调用上（网页搜索、看图、长时间工具），
  // `turn/end` 就永远不回来。`isConversationBusyV2()` 会按租约把会话判定为“忙”，
  // 期间每一条新消息都被记成「会话繁忙，暂存唤醒原因」直接丢弃 —— 用户看到的就是
  // 它突然不说话。这里给每个 turn 挂一个定时器，超时就直接 session/cancel 并解除忙碌。
  // 阈值可配：config.json 的 socialV2.turnTimeoutMs（默认 240000ms，最小 30000ms）。
  const TURN_TIMEOUT_MS = Math.max(30000, Number(cfg.socialV2?.turnTimeoutMs) || 240000);
  const turnWatchdogs = new Map(); // sessionId -> timer

  function clearTurnWatchdog(sessionId) {
    const timer = turnWatchdogs.get(sessionId);
    if (timer) {
      clearTimeout(timer);
      turnWatchdogs.delete(sessionId);
    }
  }

  async function cancelStuckTurn(sessionId) {
    if (!sessionId) return;
    if (typeof api.stopSessionWork === 'function') {
      await api.stopSessionWork(sessionId, { timeoutMs: 8000 });
    } else {
      await api.callUnary('session/cancel', { sessionId }, AbortSignal.timeout(8000));
    }
  }

  function armTurnWatchdog(sessionId) {
    clearTurnWatchdog(sessionId);
    if (!sessionId) return;
    const timer = setTimeout(() => {
      turnWatchdogs.delete(sessionId);
      const key = reverse.get(sessionId) ?? sessionId;
      log(`[reserved2] ⏱️ ${key} 回合超过 ${Math.round(TURN_TIMEOUT_MS / 1000)}s 未结束，自动取消（防“人没了”）`);
      v2TurnStartAt.delete(sessionId);
      collectors.delete(sessionId);
      turnLeaseNoted.delete(sessionId);
      if (key) pendingWakeKeys.delete(key);
      cancelStuckTurn(sessionId).catch((error) => {
        log(`[reserved2] ⏱️ 自动取消失败（${key}）: ${error?.message ?? error}`);
      });
    }, TURN_TIMEOUT_MS);
    timer.unref?.();
    turnWatchdogs.set(sessionId, timer);
  }
"""
src = src.replace(anchor, watchdog, 1)

# ── 2) trackTurnEvent：turn/end 时清看门狗 ───────────────────────────────────
old_track = """    } else if (event?.type === 'turn/end' && (!collector || collector.size?.() === 0)) {
      collectors.delete(sessionId);
      v2TurnStartAt.delete(sessionId);
      turnLeaseNoted.delete(sessionId);
    }"""
new_track = """    } else if (event?.type === 'turn/end' && (!collector || collector.size?.() === 0)) {
      collectors.delete(sessionId);
      v2TurnStartAt.delete(sessionId);
      turnLeaseNoted.delete(sessionId);
      clearTurnWatchdog(sessionId);
    }"""
assert old_track in src
src = src.replace(old_track, new_track, 1)

# ── 3) turn/start：挂看门狗 ─────────────────────────────────────────────────
old_start = """            if (frame.event.type === 'turn/start') {
              sendToolSucceededSessions.delete(frame.sessionId);
              pendingSendToolCalls.delete(frame.sessionId);
              v2TurnStartAt.set(frame.sessionId, Date.now());
              turnLeaseNoted.delete(frame.sessionId);
            }"""
new_start = """            if (frame.event.type === 'turn/start') {
              sendToolSucceededSessions.delete(frame.sessionId);
              pendingSendToolCalls.delete(frame.sessionId);
              v2TurnStartAt.set(frame.sessionId, Date.now());
              turnLeaseNoted.delete(frame.sessionId);
              armTurnWatchdog(frame.sessionId);
            }"""
assert old_start in src
src = src.replace(old_start, new_start, 1)

# ── 4) 正常回合结束分支：清看门狗 ────────────────────────────────────────────
old_end = """              v2TurnStartAt.delete(frame.sessionId);
              collectors.delete(frame.sessionId);
              turnLeaseNoted.delete(frame.sessionId);
              const sendToolSucceeded = sendToolSucceededSessions.has(frame.sessionId);"""
new_end = """              v2TurnStartAt.delete(frame.sessionId);
              collectors.delete(frame.sessionId);
              turnLeaseNoted.delete(frame.sessionId);
              clearTurnWatchdog(frame.sessionId);
              const sendToolSucceeded = sendToolSucceededSessions.has(frame.sessionId);"""
assert old_end in src
src = src.replace(old_end, new_end, 1)

io.open(P, "w", encoding="utf-8").write(src)
print("bridge.js 已加入回合超时看门狗")
