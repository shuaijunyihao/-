#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""曲库：点歌 → 用小鱼（F5 克隆）的音色唱一段高潮。

用法：
    python songbook.py list
    python songbook.py sing <歌名或别名> [输出文件名] [--bpm 100] [--speed 1.0]

曲目写成「简谱 + 歌词」的紧凑格式：
    "歌词|5:1,3:1,5:2|..."   每个字对应一个音，冒号后是拍数，"-" 是休止
简谱写法：1-7 为 do..si，数字后加 ' 升八度、加 , 降八度，0 或 - 为休止。
"""
import json
import os
import re
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import gen  # noqa: E402  复用 ffmpeg 路径、F0 估计、run 等
import f5_backend  # noqa: E402

SONGS = {}


def _song(name, bpm, lines, aliases=()):
    SONGS[name] = {"name": name, "bpm": bpm, "lines": lines, "aliases": list(aliases)}


# ── 曲库（想加歌就照这个格式加一段）──────────────────────────────
_song("小星星", 104, [
    "一闪一闪亮晶晶|1:1,1:1,5:1,5:1,6:1,6:1,5:2",
    "满天都是小星星|4:1,4:1,3:1,3:1,2:1,2:1,1:2",
], aliases=["twinkle"])
_song("两只老虎", 112, [
    "两只老虎两只老虎|1:1,2:1,3:1,1:1,1:1,2:1,3:1,1:1",
    "跑得快跑得快|3:1,4:1,5:2,3:1,4:1,5:2",
], aliases=["老虎"])
_song("生日快乐", 96, [
    "祝你生日快乐|5,5:0.5,6:1,5:1,1':1,7:2",
    "祝你生日快乐|5,5:0.5,6:1,5:1,2':1,1':2",
], aliases=["生日歌", "happy birthday"])

# 送别（长亭外）：李叔同词
_song("送别", 72, [
    "长亭外|5:1,3:1,5:2",
    "古道边|1':1,7:1,6:2",
    "芳草碧连天|5:1,1':1,2':1,3':1,2':2",
], aliases=["长亭外"])

# 茉莉花（江苏民歌）
_song("茉莉花", 88, [
    "好一朵美丽的茉莉花|3:1,3:1,5:1,6:1,1':1,1':1,6:1,5:1,5:2",
    "好一朵美丽的茉莉花|3:1,3:1,5:1,6:1,1':1,1':1,6:1,5:1,5:2",
], aliases=["茉莉"])

# 童话（光良）副歌
_song("童话", 78, [
    "我愿变成童话里|5:1,5:1,6:1,5:1,3:1,2:1,1:2",
    "你爱的那个天使|2:1,3:1,3:1,5:1,3:1,2:1,1:2",
], aliases=["光良"])

_BASE = {"1": 0, "2": 2, "3": 4, "4": 5, "5": 7, "6": 9, "7": 11}
_CN_NUM = {"一": "1", "二": "2", "三": "3", "四": "4", "五": "5", "六": "6", "七": "7", "八": "8"}


def note_to_midi(tok):
    tok = tok.strip()
    if not tok or tok in ("-", "0", "rest"):
        return None
    m = re.match(r"^([1-7])([',]*)$", tok)
    if not m:
        raise ValueError(f"看不懂的音符：{tok}")
    deg, acc = m.group(1), m.group(2)
    midi = 60 + _BASE[deg]
    for ch in acc:
        midi += 12 if ch == "'" else -12
    return midi


def midi_to_freq(m):
    return 440.0 * (2.0 ** ((m - 69) / 12.0))


def parse_song(song):
    """把 'lyric|note:beats,...' 行解析成 [(字, midi|None, 拍数)]"""
    events = []
    for line in song["lines"]:
        lyric, notes = line.split("|", 1)
        lyric = lyric.replace(" ", "")
        toks = [t for t in notes.split(",") if t.strip()]
        chars = list(lyric)
        if len(chars) != len(toks):
            raise ValueError(f"《{song['name']}》字数({len(chars)})与音符数({len(toks)})不一致：{line}")
        for ch, tok in zip(chars, toks):
            if ":" in tok:
                n, b = tok.split(":", 1)
                beats = float(b)
            else:
                n, beats = tok, 1.0
            events.append((ch, note_to_midi(n), beats))
    return events


def find_song(query):
    q = (query or "").strip()
    if not q:
        return None
    if q in SONGS:
        return SONGS[q]
    for s in SONGS.values():
        if q in s["aliases"] or q in s["name"] or s["name"] in q:
            return s
    return None


def _synth_syllable(char, idx):
    """F5 合成一个字，返回 wav 路径（16k 单声道）"""
    tmp = os.path.join(tempfile.gettempdir(), f"song_{os.getpid()}_{idx}.mp3")
    wav = os.path.join(tempfile.gettempdir(), f"song_{os.getpid()}_{idx}.wav")
    f5_backend.synth(char, tmp, speed=1.0, seed=1234 + idx * 7)
    gen.to_wav16(tmp, wav)
    return wav


def _pitch_to(wav, target_freq, duration, idx):
    f0 = gen.estimate_f0_mid(wav)
    ratio = 1.0
    if f0 > 0:
        ratio = float(min(2.2, max(0.45, target_freq / f0)))
    cur = gen.ffprobe_duration(wav)
    tempo = 1.0
    if cur > 0:
        tempo = float(min(2.0, max(0.5, cur / max(0.08, duration))))
    out = os.path.join(tempfile.gettempdir(), f"song_{os.getpid()}_{idx}_o.wav")
    af = f"rubberband=pitch={ratio:.4f}:formant=preserved,atempo={tempo:.4f},aformat=channel_layouts=mono"
    gen.run([gen.FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-i", wav, "-af", af,
             "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le", out])
    return out


def render(query, out_name=None, bpm=None, speed=1.0):
    song = find_song(query)
    if not song:
        names = "、".join(SONGS.keys())
        raise SystemExit(f"曲库里没有《{query}》。现在会唱：{names}")
    beat_bpm = float(bpm or song["bpm"])
    beat = 60.0 / beat_bpm
    events = parse_song(song)

    parts = []
    idx = 0
    for char, midi, beats in events:
        dur = max(0.12, beats * beat)
        if midi is None:
            sil = os.path.join(tempfile.gettempdir(), f"song_{os.getpid()}_r{idx}.wav")
            gen.run([gen.FFMPEG, "-y", "-hide_banner", "-loglevel", "error",
                     "-f", "lavfi", "-i", "anullsrc=r=16000:cl=mono", "-t", f"{dur:.3f}",
                     "-c:a", "pcm_s16le", sil])
            parts.append(sil)
            idx += 1
            continue
        wav = _synth_syllable(char, idx)
        parts.append(_pitch_to(wav, midi_to_freq(midi), dur, idx))
        idx += 1
        print(f"  {char} -> {midi} ({midi_to_freq(midi):.0f}Hz) {dur:.2f}s", file=sys.stderr)

    if not parts:
        raise SystemExit("没有可唱的音符")

    listfile = os.path.join(tempfile.gettempdir(), f"song_{os.getpid()}_list.txt")
    with open(listfile, "w", encoding="utf-8") as f:
        for p in parts:
            f.write(f"file '{p.replace(chr(92), '/')}'\n")

    out_name = out_name or f"{song['name']}.wav"
    if not out_name.lower().endswith(".wav"):
        out_name += ".wav"
    raw = os.path.join(gen.AUDIO_DIR, out_name)
    os.makedirs(gen.AUDIO_DIR, exist_ok=True)
    gen.run([gen.FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-f", "concat", "-safe", "0",
             "-i", listfile, "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le", raw])

    # 轻混响 + 响度标准化，比干声更像"唱"
    final = raw.replace(".wav", "_final.wav")
    af = ("aecho=0.8:0.9:40:0.25,"
          "loudnorm=I=-16:TP=-1.5:LRA=11")
    gen.run([gen.FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-i", raw, "-af", af,
             "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le", final])
    os.replace(final, raw)
    print(raw)
    return raw


def main():
    args = [a for a in sys.argv[1:]]
    if not args:
        print(__doc__)
        return
    cmd = args[0]
    if cmd == "list":
        for name, s in SONGS.items():
            print(f"{name}（{'/'.join(s['aliases'])}）bpm={s['bpm']}")
        return
    if cmd == "sing":
        query = args[1] if len(args) > 1 else ""
        out = args[2] if len(args) > 2 else None
        bpm = None
        if "--bpm" in args:
            bpm = float(args[args.index("--bpm") + 1])
        render(query, out, bpm)
        return
    print(__doc__)


if __name__ == "__main__":
    main()