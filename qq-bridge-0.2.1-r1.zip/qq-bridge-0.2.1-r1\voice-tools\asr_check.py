import os
import subprocess
import sys
import tempfile
import wave

import numpy as np
from faster_whisper import WhisperModel

HERE = os.path.dirname(os.path.abspath(__file__))
FFMPEG = os.environ.get("FFMPEG_PATH") or "ffmpeg"
m = WhisperModel("small", device="cpu", compute_type="int8")


def load16k(path):
    tmp = os.path.join(tempfile.gettempdir(), "asr_" + os.path.basename(path) + ".16k.wav")
    subprocess.run(
        [FFMPEG, "-hide_banner", "-loglevel", "error", "-y", "-i", path, "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", tmp],
        check=True,
    )
    w = wave.open(tmp)
    return np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768, w.getframerate()


for name in sys.argv[1:]:
    p = name if os.path.isabs(name) else os.path.join(HERE, "out", name + ".wav")
    a, sr = load16k(p)
    segs, _ = m.transcribe(a, language="zh")
    print(f"{os.path.basename(p)} ({len(a)/sr:.2f}s) -> {''.join(s.text for s in segs)}", flush=True)
