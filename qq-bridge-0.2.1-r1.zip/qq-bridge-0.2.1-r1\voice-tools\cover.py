#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""一键翻唱：搜索/下载 → 分轨 → Seed-VC 换声 → 混音出成品。

用法：
    python cover.py "宿敌" out.wav [--ref ref.wav] [--json]

输出最后一行是 JSON：{"ok":true,"title":..,"duration":..,"out":..}
"""
import os, sys, json, re, glob, shutil, subprocess, tempfile, urllib.parse, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
D_ROOT = os.environ.get("DSH_VOICE_ROOT") or r"D:\dsh-voice"
VENV_PY = os.path.join(D_ROOT, "venv", "Scripts", "python.exe")
SEEDVC_DIR = os.path.join(D_ROOT, "seed-vc-main")
SEEDVC_PY = VENV_PY
MODEL = os.path.join(D_ROOT, "models", "DiT_seed_v2_44k_ema_v2.pth")
CONFIG = "configs/presets/config_dit_mel_seed_uvit_whisper_base_f0_44k.yml"
DEFAULT_REF = os.path.join(HERE, "ref", "xinyu_ref.wav")
FFMPEG = os.environ.get("FFMPEG_PATH") or shutil.which("ffmpeg") or "ffmpeg"
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"
BV_RE = re.compile(r"(BV[0-9A-Za-z]{10})")


def log(*a):
    print(*a, file=sys.stderr, flush=True)


def run(cmd, cwd=None, env=None, timeout=1800):
    log("$", " ".join(str(c) for c in cmd[:6]))
    r = subprocess.run(cmd, cwd=cwd, env=env, capture_output=True, text=True, timeout=timeout)
    if r.returncode != 0:
        tail = (r.stderr or r.stdout or "").strip().splitlines()[-6:]
        raise RuntimeError("命令失败：" + " | ".join(tail))
    return r


def resolve(query):
    """返回 (bvid, title)。支持 BV 号 / 链接 / 歌名搜索。"""
    m = BV_RE.search(query)
    if m:
        return m.group(1), query.strip()
    import http.cookiejar, time
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
    opener.addheaders = [("User-Agent", UA), ("Referer", "https://www.bilibili.com/")]
    try:
        opener.open("https://www.bilibili.com/", timeout=20).read()
    except Exception:
        pass
    pool = {}
    for q in (query, query + " 原唱", query + " 完整版"):
        api = ("https://api.bilibili.com/x/web-interface/search/type?search_type=video&page=1&page_size=20&keyword="
               + urllib.parse.quote(q))
        data = None
        for attempt in range(3):
            try:
                data = json.load(opener.open(api, timeout=30))
                break
            except Exception as e:
                last = e
                time.sleep(2 + attempt * 2)
        if not data:
            continue
        for it in (((data or {}).get("data") or {}).get("result") or []):
            if it.get("bvid") and it["bvid"] not in pool:
                pool[it["bvid"]] = it
    items = list(pool.values())
    if not items:
        raise RuntimeError(f"搜索《{query}》被拦（{last}），可以改发 BV 号")

    def dur_sec(it):
        s = str(it.get("duration") or "")
        try:
            p = [int(x) for x in s.split(":")]
        except Exception:
            return 0
        if len(p) == 2:
            return p[0] * 60 + p[1]
        if len(p) == 3:
            return p[0] * 3600 + p[1] * 60 + p[2]
        return 0

    def score(it):
        title = re.sub(r"<[^>]+>", "", str(it.get("title") or ""))
        play = int(it.get("play") or 0)
        s = play ** 0.6
        if query.replace(" ", "") in title.replace(" ", ""):
            s *= 2.0
        if any(w in title for w in ("原唱", "官方", "无损", "Hi-Res", "HiRes", "完整版", "原曲", "录音棚")):
            s *= 1.5
        if any(w in title for w in ("合集", "串烧", "连播", "循环", "三巨头", "精选", "歌单", "一小时", "半小时", "排行榜")):
            s *= 0.25
        d = dur_sec(it)
        s *= 1.0 if 90 <= d <= 420 else 0.3
        return s

    items.sort(key=score, reverse=True)
    best = items[0]
    title = re.sub(r"<[^>]+>", "", best.get("title") or query)
    return best["bvid"], title


def download(bvid, work):
    url = f"https://www.bilibili.com/video/{bvid}"
    out = os.path.join(work, "src.%(ext)s")
    run([VENV_PY, "-m", "yt_dlp", "-f", "bestaudio/best", "--no-playlist", "-x",
         "--audio-format", "wav", "--audio-quality", "0", "-o", out, url], timeout=900)
    files = glob.glob(os.path.join(work, "src.wav")) or glob.glob(os.path.join(work, "src.*"))
    if not files:
        raise RuntimeError("下载失败：没有生成音频")
    return files[0]


def separate(src, work):
    outdir = os.path.join(work, "sep")
    env = dict(os.environ)
    env.setdefault("HF_ENDPOINT", "https://hf-mirror.com")
    run([VENV_PY, "-m", "demucs", "-n", "htdemucs", "--two-stems=vocals", "-o", outdir, src],
        env=env, timeout=1800)
    base = os.path.splitext(os.path.basename(src))[0]
    d = os.path.join(outdir, "htdemucs", base)
    v = os.path.join(d, "vocals.wav")
    inst = os.path.join(d, "no_vocals.wav")
    if not (os.path.exists(v) and os.path.exists(inst)):
        raise RuntimeError("分轨失败")
    return v, inst


def convert(vocals, ref, work):
    outdir = os.path.join(work, "vc")
    os.makedirs(outdir, exist_ok=True)
    env = dict(os.environ)
    env["HF_ENDPOINT"] = "https://hf-mirror.com"
    run([SEEDVC_PY, "-u", "inference.py", "--source", vocals, "--target", ref, "--output", outdir,
         "--auto-f0-adjust", "True", "--inference-cfg-rate", "1.0", "--diffusion-steps", "40",
         "--f0-condition", "True", "--checkpoint", MODEL, "--config", CONFIG, "--fp16", "False"],
        cwd=SEEDVC_DIR, env=env, timeout=3600)
    files = glob.glob(os.path.join(outdir, "*.wav"))
    if not files:
        raise RuntimeError("换声失败：没有输出")
    files.sort(key=lambda p: os.path.getmtime(p), reverse=True)
    return files[0]



def probe_dur(path):
    try:
        out = subprocess.run([FFMPEG.replace("ffmpeg.exe", "ffprobe.exe"), "-v", "error",
                              "-show_entries", "format=duration", "-of",
                              "default=nw=1:nk=1", path],
                             capture_output=True, text=True, timeout=60).stdout.strip()
        return float(out or 0)
    except Exception:
        return 0.0


def fit_under(src, out, limit=292.0):
    """把成品压到 limit 秒以内：优先轻微提速（音准不变），仍然太长就截断。"""
    dur = probe_dur(src)
    if dur <= limit or dur <= 0:
        if os.path.abspath(src) != os.path.abspath(out):
            shutil.copyfile(src, out)
        return probe_dur(out)
    tempo = min(1.35, dur / limit)
    run([FFMPEG, "-hide_banner", "-loglevel", "error", "-y", "-i", src,
         "-filter:a", f"atempo={tempo:.4f}", "-t", str(limit),
         "-c:a", "pcm_s16le", out], timeout=600)
    log(f"   时长 {dur:.1f}s 超过上限，已提速 {tempo:.3f}x → {probe_dur(out):.1f}s")
    return probe_dur(out)


def mix(voice, inst, out_wav):
    post = ("highpass=f=85,equalizer=f=6800:t=q:w=2.5:g=-4,equalizer=f=8500:t=q:w=3:g=-3,"
            "acompressor=threshold=-20dB:ratio=3.5:attack=8:release=180,"
            "equalizer=f=3000:t=q:w=1.4:g=1.5,aecho=0.85:0.75:32:0.10,")
    fc = (f"[0:a]aresample=44100,aformat=sample_fmts=fltp:channel_layouts=stereo,{post}"
          "volume=3dB,alimiter=limit=0.89[v];"
          "[1:a]aresample=44100,aformat=sample_fmts=fltp:channel_layouts=stereo,volume=-1dB[i];"
          "[v][i]amix=inputs=2:duration=first:normalize=0,"
          "loudnorm=I=-14:LRA=11:TP=-1.0,aresample=16000,aformat=channel_layouts=mono[m]")
    os.makedirs(os.path.dirname(out_wav), exist_ok=True)
    run([FFMPEG, "-hide_banner", "-loglevel", "error", "-y", "-i", voice, "-i", inst,
         "-filter_complex", fc, "-map", "[m]", "-c:a", "pcm_s16le", out_wav], timeout=900)
    return out_wav


def _keep_awake():
    """翻唱期间禁止系统睡眠/休眠，跑完再放开。"""
    try:
        import ctypes
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)  # ES_CONTINUOUS | ES_SYSTEM_REQUIRED
        return lambda: ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
    except Exception:
        return lambda: None


def main():
    _release = _keep_awake()
    try:
        return _main_impl()
    finally:
        _release()


def _main_impl():
    args = [a for a in sys.argv[1:]]
    if len(args) < 2:
        print(json.dumps({"ok": False, "error": "用法：cover.py <歌名|BV号> <out.wav> [ref.wav]"}))
        return 2
    query, out_wav = args[0], os.path.abspath(args[1])
    ref = args[2] if len(args) > 2 and not args[2].startswith("--") else DEFAULT_REF
    if not os.path.exists(ref):
        ref = DEFAULT_REF
    work = tempfile.mkdtemp(prefix="cover_", dir=os.path.join(D_ROOT, "work") if os.path.isdir(os.path.join(D_ROOT, "work")) else None)
    try:
        if os.path.exists(query):
            bvid, title, src = "", os.path.basename(query), query
            log("[1/4] 本地文件", src)
        else:
            log("[1/4] 搜索", query)
            bvid, title = resolve(query)
            log("   ->", bvid, title)
            log("[2/4] 下载")
            src = download(bvid, work)
            d0 = probe_dur(src)
            if d0 > 420:
                trimmed = os.path.join(work, "src_trim.wav")
                run([FFMPEG, "-hide_banner", "-loglevel", "error", "-y", "-i", src,
                     "-t", "420", "-c:a", "pcm_s16le", trimmed], timeout=600)
                log(f"   源音频 {d0:.0f}s 偏长，截取前 420s")
                src = trimmed
        log("[3/4] 分轨")
        vocals, inst = separate(src, work)
        log("[4/4] 换声（几分钟）")
        voice = convert(vocals, ref, work)
        mix(voice, inst, out_wav)
        fitted = os.path.join(work, "fitted.wav")
        dur = fit_under(out_wav, fitted, 292.0)
        if os.path.abspath(fitted) != os.path.abspath(out_wav):
            shutil.move(fitted, out_wav)
        print(json.dumps({"ok": True, "title": title, "bvid": bvid,
                          "duration": round(dur, 1), "out": out_wav}, ensure_ascii=False))
        return 0
    except Exception as e:
        print(json.dumps({"ok": False, "error": str(e)[:400]}, ensure_ascii=False))
        return 1
    finally:
        try:
            shutil.rmtree(work, ignore_errors=True)
        except Exception:
            pass


if __name__ == "__main__":
    sys.exit(main())