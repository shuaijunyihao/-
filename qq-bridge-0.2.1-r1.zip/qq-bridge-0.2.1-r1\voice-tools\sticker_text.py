#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""把一句话压在图片上，做成表情包（白字黑描边，经典 meme 风）。

用法：python sticker_text.py <输入图> <输出图> <文字> [字号]
"""
import sys
import os
from PIL import Image, ImageDraw, ImageFont

FONTS = [
    r"C:\Windows\Fonts\msyhbd.ttc",
    r"C:\Windows\Fonts\msyh.ttc",
    r"C:\Windows\Fonts\simhei.ttf",
]
# 行首不该出现的标点
NO_HEAD = "，。！？、；：」』）…~～, !?;:)]}"


def load_font(size):
    for f in FONTS:
        if os.path.exists(f):
            try:
                return ImageFont.truetype(f, size)
            except Exception:
                continue
    return ImageFont.load_default()


def wrap(draw, text, font, max_w):
    lines, cur = [], ""
    for ch in text:
        trial = cur + ch
        w = draw.textlength(trial, font=font)
        if w > max_w and cur:
            if ch in NO_HEAD:
                # 标点不放行首：留在上一行
                lines.append(cur + ch)
                cur = ""
                continue
            lines.append(cur)
            cur = ch
        else:
            cur = trial
    if cur:
        lines.append(cur)
    return lines


def main():
    if len(sys.argv) < 4:
        print("usage: sticker_text.py <in> <out> <text> [fontsize]", file=sys.stderr)
        return 2
    src, dst, text = sys.argv[1], sys.argv[2], sys.argv[3]
    size = int(sys.argv[4]) if len(sys.argv) > 4 else 0

    im = Image.open(src).convert("RGB")
    # 取中间正方形再缩到 640
    w, h = im.size
    side = min(w, h)
    im = im.crop(((w - side) // 2, (h - side) // 2, (w + side) // 2, (h + side) // 2)).resize((640, 640), Image.LANCZOS)

    if not text.strip():
        im.save(dst, quality=92)
        return 0

    # 字号：按字数自适应
    font_size = size or (86 if len(text) <= 4 else 72 if len(text) <= 8 else 58 if len(text) <= 14 else 46)
    font = load_font(font_size)
    draw = ImageDraw.Draw(im)
    max_w = 640 - 56
    lines = wrap(draw, text, font, max_w)

    line_h = int(font_size * 1.25)
    total_h = line_h * len(lines)
    # 默认压在底部，若文字太高就整体居中偏下
    top = 640 - total_h - 34
    if top < 24:
        top = (640 - total_h) // 2

    stroke = max(3, font_size // 14)
    y = top
    for line in lines:
        lw = draw.textlength(line, font=font)
        x = (640 - lw) / 2
        draw.text((x, y), line, font=font, fill=(255, 255, 255), stroke_width=stroke, stroke_fill=(0, 0, 0))
        y += line_h
    im.save(dst, quality=92)
    return 0


if __name__ == "__main__":
    sys.exit(main())