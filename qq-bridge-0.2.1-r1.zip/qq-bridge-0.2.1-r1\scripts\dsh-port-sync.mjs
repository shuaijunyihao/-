#!/usr/bin/env node
/**
 * 让 config.json 里的 dsh.baseUrl 始终跟本机正在运行的 DSH Web 端口一致。
 *
 * 背景（2026-11-07 事故）：DSH 每次重启都会换一个随机 web 端口
 * （19387 → 58963 → 58041 → 50263 …），而 config.json 里是写死的地址。
 * 一旦对不上，桥接就会「连上 DSH 事件流但一帧都收不到」，重连指数退避也永远
 * 连不回来 —— 表现为大肥鱼掉线：dshReady=false、mode 退回默认的 chat。
 *
 * 用法：
 *   node scripts/dsh-port-sync.mjs           只检查一次
 *   node scripts/dsh-port-sync.mjs --watch   常驻，每 45 秒检查一次（start.bat 后台拉起）
 *   node scripts/dsh-port-sync.mjs --port 50263 --dry-run
 *                                            手动指定候选端口 / 只打印不改写（调试用）
 *
 * 判定 DSH 端口的方式（两个指纹，命中任意一个即可）：
 *   1. GET /dsh-bigfish/ → 200 且 Server 头以 DafeiyuAdmin 开头（插件反代到后台面板）
 *   2. GET /            → 401 且 Content-Type 为 text/plain 且带 Vary 头（DSH 根路径要求鉴权）
 * 这两个特征与 SnowLuma(3000)、桥接(3100)、后台(3200) 都不重合。
 */
import { readFileSync, writeFileSync, appendFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '..');
const CONFIG_PATH = path.join(ROOT, 'config.json');
const STATE_DIR = path.join(ROOT, 'state');
const LOG_PATH = path.join(STATE_DIR, 'dsh-port-sync.log');
const TOKEN_PATH = path.join(STATE_DIR, 'console-token');
const PID_PATH = path.join(STATE_DIR, 'dsh-port-sync.pid');

const BRIDGE_URL = 'http://127.0.0.1:3100';
const WATCH_MS = 45_000;
// 这些端口是我们自己的服务，绝不当成 DSH 去探测
const SKIP_PORTS = new Set([3000, 3001, 3100, 3200, 5099]);

function log(msg) {
  const line = `${new Date().toISOString()}  ${msg}`;
  try {
    appendFileSync(LOG_PATH, line + '\r\n');
  } catch {
    // 日志写不了也不能影响主流程
  }
  if (!process.argv.includes('--quiet')) console.log(line);
}

function cliPorts() {
  const out = [];
  const argv = process.argv.slice(2);
  for (let i = 0; i < argv.length; i += 1) {
    const m = argv[i].match(/^--port(?:=(.+)|)$/);
    if (!m) continue;
    const raw = m[1] ?? argv[i + 1] ?? '';
    for (const piece of String(raw).split(',')) {
      const n = Number(piece.trim());
      if (Number.isFinite(n) && n > 0) out.push(n);
    }
  }
  return out;
}

/** 本机处于 LISTENING 的候选端口 */
function listListeningPorts() {
  const manual = cliPorts();
  if (manual.length) return [...new Set(manual)];
  let out = '';
  try {
    out = execFileSync('netstat', ['-ano'], {
      encoding: 'utf8',
      windowsHide: true,
      timeout: 10_000,
      maxBuffer: 8 * 1024 * 1024,
    });
  } catch (err) {
    log(`netstat 失败：${err.message}`);
    return [];
  }
  const ports = new Set();
  for (const line of out.split(/\r?\n/)) {
    const m = line.match(/^\s*TCP\s+(\S+):(\d+)\s+\S+\s+LISTENING\s+\d+/i);
    if (!m) continue;
    const host = m[1];
    const port = Number(m[2]);
    if (!Number.isFinite(port) || port < 1024) continue;
    if (host !== '0.0.0.0' && host !== '127.0.0.1' && host !== '[::]' && host !== '[::1]') continue;
    if (SKIP_PORTS.has(port)) continue;
    ports.add(port);
  }
  return [...ports];
}

function httpProbe(port, reqPath, timeoutMs = 1200) {
  return new Promise((resolve, reject) => {
    const req = http.get(
      { host: '127.0.0.1', port, path: reqPath, timeout: timeoutMs, headers: { Connection: 'close' } },
      (res) => {
        const chunks = [];
        let size = 0;
        res.on('data', (c) => {
          size += c.length;
          if (size < 8192) chunks.push(c);
        });
        res.on('end', () => resolve({ status: res.statusCode, headers: res.headers }));
        res.on('error', reject);
      },
    );
    req.on('timeout', () => {
      req.destroy(new Error('timeout'));
    });
    req.on('error', reject);
  });
}

function looksLikeDshProxy(res) {
  const server = String(res.headers.server || '');
  return res.status === 200 && server.startsWith('DafeiyuAdmin');
}

function looksLikeDshRoot(res) {
  const ct = String(res.headers['content-type'] || '');
  return res.status === 401 && ct.includes('text/plain') && Boolean(res.headers.vary);
}

async function probePort(port) {
  try {
    if (looksLikeDshProxy(await httpProbe(port, '/dsh-bigfish/'))) return true;
  } catch {
    /* 端口不是 HTTP 或已关闭，继续 */
  }
  try {
    if (looksLikeDshRoot(await httpProbe(port, '/'))) return true;
  } catch {
    /* ignore */
  }
  return false;
}

async function discoverDshPorts() {
  const ports = listListeningPorts();
  if (!ports.length) return [];
  const flags = await Promise.all(ports.map((p) => probePort(p)));
  return ports.filter((_, i) => flags[i]);
}

function readCurrentBaseUrl() {
  try {
    const cfg = JSON.parse(readFileSync(CONFIG_PATH, 'utf8'));
    return String(cfg?.dsh?.baseUrl || '');
  } catch (err) {
    log(`读 config.json 失败：${err.message}`);
    return '';
  }
}

function portOf(baseUrl) {
  try {
    return Number(new URL(baseUrl).port) || 0;
  } catch {
    return 0;
  }
}

function patchBaseUrl(targetPort) {
  const text = readFileSync(CONFIG_PATH, 'utf8');
  // 只替换第一处 127.0.0.1 的 http baseUrl（就是 dsh 那一块），
  // 保留原有缩进与其余内容，避免把整份配置重新序列化。
  const re = /("baseUrl"\s*:\s*")http:\/\/127\.0\.0\.1:\d+(")/;
  if (!re.test(text)) {
    log('config.json 里没找到 dsh.baseUrl，放弃改写');
    return false;
  }
  const next = text.replace(re, `$1http://127.0.0.1:${targetPort}$2`);
  writeFileSync(CONFIG_PATH, next, 'utf8');
  return true;
}

function bridgeRestart() {
  return new Promise((resolve) => {
    let token = '';
    try {
      token = readFileSync(TOKEN_PATH, 'utf8').trim();
    } catch {
      /* 没有令牌就试无鉴权，通常会被拒 */
    }
    const body = '{}';
    const req = http.request(
      {
        host: '127.0.0.1',
        port: 3100,
        path: '/api/restart',
        method: 'POST',
        timeout: 5000,
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(body),
          ...(token ? { 'x-console-token': token } : {}),
        },
      },
      (res) => {
        res.resume();
        res.on('end', () => resolve(res.statusCode === 200));
      },
    );
    req.on('timeout', () => req.destroy(new Error('timeout')));
    req.on('error', () => resolve(false));
    req.write(body);
    req.end();
  });
}

async function syncOnce() {
  const current = readCurrentBaseUrl();
  const currentPort = portOf(current);
  const found = await discoverDshPorts();
  if (!found.length) {
    log('没找到 DSH 端口（DSH 可能没在跑），本轮跳过');
    return;
  }
  if (found.includes(currentPort)) {
    // 配置是对的，什么都不用做（保持安静，避免日志刷屏）
    return;
  }
  const target = found.sort((a, b) => a - b)[0];
  log(`检测到 DSH 端口变化：config=${currentPort || '(空)'} → 实际=${target}，改写 config.json`);
  if (process.argv.includes('--dry-run')) {
    log('--dry-run：不写配置、不重启桥接');
    return;
  }
  if (!patchBaseUrl(target)) return;
  const ok = await bridgeRestart();
  log(ok ? '已请求桥接重启，新端口生效' : '桥接重启请求失败（桥接可能没在跑，等它自己起来即可）');
}

function alreadyRunning() {
  try {
    const pid = Number(readFileSync(PID_PATH, 'utf8').trim());
    if (!Number.isFinite(pid) || pid <= 0 || pid === process.pid) return false;
    process.kill(pid, 0); // 只为探活，不发信号
    return true;
  } catch {
    return false;
  }
}

function claimPidFile() {
  try {
    writeFileSync(PID_PATH, String(process.pid), 'utf8');
  } catch {
    /* state/ 不可写也不致命，只是少了单实例保护 */
  }
  const release = () => {
    try {
      if (Number(readFileSync(PID_PATH, 'utf8').trim()) === process.pid) {
        writeFileSync(PID_PATH, '', 'utf8');
      }
    } catch {
      /* ignore */
    }
  };
  process.on('exit', release);
  process.on('SIGINT', () => process.exit(0));
  process.on('SIGTERM', () => process.exit(0));
}

async function main() {
  if (process.argv.includes('--list')) {
    const found = await discoverDshPorts();
    log(`扫描到 DSH 端口：${found.join(', ') || '(无)'}；config=${portOf(readCurrentBaseUrl())}`);
    return;
  }
  if (!process.argv.includes('--watch')) {
    await syncOnce();
    return;
  }
  if (alreadyRunning()) {
    log('已有端口同步守护在跑，本实例退出');
    return;
  }
  claimPidFile();
  log('端口同步守护启动（每 45 秒检查一次）');
  // 轻量单实例保护：上一次守护还活着就不再起第二个
  let running = false;
  const tick = async () => {
    if (running) return;
    running = true;
    try {
      await syncOnce();
    } catch (err) {
      log(`本轮异常：${err.message}`);
    } finally {
      running = false;
    }
  };
  await tick();
  setInterval(tick, WATCH_MS);
}

main().catch((err) => {
  log(`致命错误：${err && err.stack ? err.stack : err}`);
  process.exitCode = 1;
});