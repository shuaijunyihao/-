#!/usr/bin/env python3
"""大肥鱼后台 — 本地控制台（标准库实现，无需第三方依赖）。

提供：状态查看、重启（桥接/网关/DSH）、日志、角色/模式切换、会话重置、模块安装。
仅监听 127.0.0.1，端口 3200。UI 在同目录 ui.html。
"""
from __future__ import annotations

import json
import mimetypes
import os
import re
import shutil
import subprocess

CREATE_NO_WINDOW_FLAG = 0x08000000
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HERE = Path(__file__).resolve().parent
BRIDGE_DIR = HERE.parent
STATE_DIR = BRIDGE_DIR / "state"
ASSETS_DIR = BRIDGE_DIR / "assets"
PORT = 3200
HOST = "127.0.0.1"


# ---------------------------------------------------------------- 路径自愈
# 这个面板以前把八条 Windows 绝对路径写死在源码里，换台电脑就全废。
# 现在一律现场探测：先看环境变量，再看本机常见位置，最后看 config.json。
# 探测不到的项留空字符串，用到它的功能自己会报「未配置」而不是抛异常。

def _first_existing(*cands: str | None) -> str:
    for c in cands:
        if c and Path(c).exists():
            return str(Path(c))
    return ""


def _env(*names: str) -> str | None:
    for n in names:
        v = os.environ.get(n)
        if v:
            return v
    return None


def _load_config() -> dict:
    try:
        return json.loads((BRIDGE_DIR / "config.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


CONFIG = _load_config()


def _dsh_home() -> Path:
    return Path(_env("DSH_HOME") or (Path.home() / ".dsh"))


def _profile_dir() -> Path:
    """DSH 的 profile 目录。desktop 是桌面端默认档，用户装了别的就挑一个。"""
    explicit = _env("DSH_PROFILE_DIR")
    if explicit:
        return Path(explicit)
    root = _dsh_home() / "profiles"
    if (root / "desktop").is_dir():
        return root / "desktop"
    if root.is_dir():
        for entry in root.iterdir():
            if entry.is_dir():
                return entry
    return root / "desktop"


def _snowluma_dir() -> Path:
    """网关目录。config.json 里的 snowluma.homeDir/launcherPath 优先。"""
    sl = CONFIG.get("snowluma") or {}
    for key in ("homeDir", "launcherPath"):
        v = sl.get(key)
        if v:
            p = Path(v)
            p = p.parent if p.is_file() else p
            if p.is_dir():
                return p
    cands = [
        _env("SNOWLUMA_DIR"),
        r"C:\SnowLuma\SnowLuma-v2.1.1-win-x64",
        r"C:\SnowLuma",
    ]
    for c in cands:
        if c and Path(c).is_dir():
            return Path(c)
    base = Path(r"C:\SnowLuma")
    if base.is_dir():
        for entry in base.iterdir():
            if entry.is_dir() and (entry / "index.mjs").exists():
                return entry
    return base


def _dsh_exe() -> str:
    cands = [
        _env("DSH_EXE"),
        str(Path.home() / "AppData" / "Local" / "Programs" / "DeepSeek Harness" / "DeepSeek Harness.exe"),
        r"C:\Program Files\DeepSeek Harness\DeepSeek Harness.exe",
    ]
    for c in cands:
        if c and Path(c).exists():
            return c
    # 最后问一下注册表的卸载项
    try:
        import winreg
        for hive in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
            try:
                with winreg.OpenKey(hive, r"Software\Microsoft\Windows\CurrentVersion\Uninstall\DeepSeekHarness") as k:
                    loc, _ = winreg.QueryValueEx(k, "InstallLocation")
                    exe = Path(loc) / "DeepSeek Harness.exe"
                    if exe.exists():
                        return str(exe)
            except OSError:
                continue
    except Exception:
        pass
    return ""


def _node() -> str:
    return _first_existing(
        _env("NODE_EXE"),
        shutil.which("node"),
        r"C:\Program Files\nodejs\node.exe",
        r"C:\Program Files (x86)\nodejs\node.exe",
    )


def _pnpm() -> str:
    return _first_existing(
        _env("PNPM_JS"),
        str(_dsh_home() / "dsh-runtimes" / "dsh-primary-runtime" / "dependencies" / "pnpm" / "bin" / "pnpm.mjs"),
        shutil.which("pnpm"),
    )


def _voice_py() -> str:
    """翻唱用的 Seed-VC venv。找不到就空，翻唱功能会报未配置。"""
    cands = [
        _env("VOICE_PY", "BIGFISH_VOICE_PY"),
        r"D:\dsh-voice\venv\Scripts\python.exe",
        str(BRIDGE_DIR / "voice-tools" / "venv" / "Scripts" / "python.exe"),
        str(_dsh_home() / "voice" / "venv" / "Scripts" / "python.exe"),
    ]
    return _first_existing(*cands)


PROFILE_DIR = _profile_dir()
PLUGINS_DIR = _dsh_home() / "plugins"
SNOWLUMA_DIR = _snowluma_dir()
DSH_EXE = _dsh_exe()
NODE = _node()
PNPM = _pnpm()
VOICE_PY = _voice_py()

# 桥接控制台端口/令牌也来自配置，不再假设 3100 / 假设令牌在哪个文件
BRIDGE_PORT = int(CONFIG.get("consolePort") or _env("BIGFISH_CONSOLE_PORT") or 3100)
BRIDGE_TOKEN = str(CONFIG.get("consoleToken") or "")

JOBS: dict[str, dict] = {}
JOBS_LOCK = threading.Lock()


# ---------------------------------------------------------------- bridge api
def console_token() -> str:
    """令牌优先取 config.json 的 consoleToken，其次 state/console-token 文件。"""
    if BRIDGE_TOKEN:
        return BRIDGE_TOKEN
    try:
        return (STATE_DIR / "console-token").read_text(encoding="utf-8").strip()
    except OSError:
        return ""


def bridge_call(path: str, method: str = "GET", body: dict | None = None, timeout: float = 30.0) -> dict:
    url = f"http://127.0.0.1:{BRIDGE_PORT}{path}"
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("x-console-token", console_token())
    if data:
        req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def bridge_status() -> dict | None:
    try:
        return bridge_call("/api/status", timeout=8)
    except Exception:
        return None


# ---------------------------------------------------------------- 对话目标
KEY_RE = re.compile(r"^(private|group):(\d{4,12})$")


def whitelist() -> dict:
    try:
        return bridge_call("/api/whitelist", timeout=8)
    except Exception:
        return {"allow": {"private": [], "groups": []}, "deny": {"private": [], "groups": []}, "ownerQQ": None}


def save_allow(allow: dict) -> None:
    wl = whitelist()
    payload = {
        "allow": {"private": sorted({int(x) for x in allow.get("private", [])}),
                  "groups": sorted({int(x) for x in allow.get("groups", [])})},
        "deny": wl.get("deny") or {"private": [], "groups": []},
    }
    if wl.get("ownerQQ") is not None:
        payload["ownerQQ"] = wl["ownerQQ"]
    bridge_call("/api/whitelist", "POST", payload, timeout=10)


def parse_key(raw: str) -> tuple[str, int] | None:
    raw = (raw or "").strip()
    m = KEY_RE.match(raw)
    if m:
        return m.group(1), int(m.group(2))
    if re.fullmatch(r"\d{4,12}", raw):
        return "private", int(raw)
    return None


def wake_agent(key: str, message: str) -> dict:
    return bridge_call("/api/console/notify-ai", "POST", {"key": key, "message": message}, timeout=20)


# ---------------------------------------------------------------- process helpers
def run(cmd: list[str], cwd: str | None = None, timeout: float = 120.0) -> tuple[int, str]:
    try:
        p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout,
                           encoding="utf-8", errors="replace", creationflags=CREATE_NO_WINDOW_FLAG)
        return p.returncode, (p.stdout or "") + (p.stderr or "")
    except subprocess.TimeoutExpired:
        return -1, "超时"
    except Exception as e:  # noqa: BLE001
        return -1, str(e)


def snowluma_pids() -> list[int]:
    rc, out = run(["powershell", "-NoProfile", "-Command",
                   "Get-CimInstance Win32_Process -Filter \"Name='node.exe'\" | "
                   "Where-Object { $_.CommandLine -match 'SnowLuma.v2.1.1' -and $_.CommandLine -match 'index.mjs' } | "
                   "ForEach-Object { $_.ProcessId }"], timeout=40)
    return [int(x) for x in out.split() if x.strip().isdigit()]


def start_snowluma() -> None:
    line = f'cmd.exe /c cd /d "{SNOWLUMA_DIR}" && node.exe index.mjs'
    run(["powershell", "-NoProfile", "-Command",
         f"$r = Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{{CommandLine='{line}'}}; $r.ProcessId"],
         timeout=40)


def restart_snowluma() -> str:
    pids = snowluma_pids()
    for pid in pids:
        run(["taskkill", "/F", "/PID", str(pid)], timeout=30)
    time.sleep(2)
    start_snowluma()
    return f"已重启网关（原进程 {pids or '无'}）"


def restart_dsh(delay: int = 6) -> None:
    script = (
        f"Start-Sleep -Seconds {delay}; "
        f'Stop-Process -Name "DeepSeek Harness" -Force -ErrorAction SilentlyContinue; '
        f"Start-Sleep -Seconds 4; "
        f"Start-Process '{DSH_EXE}'"
    )
    subprocess.Popen(["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", script],
                     creationflags=0x00000008 | 0x00000200,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


# ---------------------------------------------------------------- jobs
def new_job(title: str, cmd: list[str], cwd: str | None = None) -> str:
    job_id = uuid.uuid4().hex[:12]
    job = {"id": job_id, "title": title, "output": "", "done": False, "code": None,
           "started": time.time()}
    with JOBS_LOCK:
        JOBS[job_id] = job

    def worker() -> None:
        try:
            p = subprocess.Popen(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                 text=True, encoding="utf-8", errors="replace",
                                 creationflags=0x08000000)
            assert p.stdout is not None
            for line in p.stdout:
                job["output"] = (job["output"] + line)[-20000:]
            job["code"] = p.wait()
        except Exception as e:  # noqa: BLE001
            job["output"] += f"\n[错误] {e}"
            job["code"] = -1
        finally:
            job["done"] = True

    threading.Thread(target=worker, daemon=True).start()
    return job_id


# ---------------------------------------------------------------- modules
def profile_pkg() -> dict:
    return json.loads((PROFILE_DIR / "package.json").read_text(encoding="utf-8"))


def save_profile_pkg(pkg: dict) -> None:
    p = PROFILE_DIR / "package.json"
    backup = PROFILE_DIR / f"package.json.bak-{time.strftime('%Y%m%d-%H%M%S')}"
    shutil.copyfile(p, backup)
    p.write_text(json.dumps(pkg, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def installed_plugins() -> list[dict]:
    try:
        pkg = profile_pkg()
    except Exception:
        return []
    deps = pkg.get("dependencies", {})
    bundles = pkg.get("dsh", {}).get("profile", {}).get("bundles", [])
    out = []
    for name, spec in deps.items():
        out.append({"name": name, "spec": spec, "bundled": name in bundles})
    return out


def install_npm_job(spec: str) -> str:
    def cmd_sequence() -> list[str]:
        return [NODE, PNPM, "add", spec]

    def worker() -> None:
        code, out = run([NODE, PNPM, "add", spec], cwd=str(PROFILE_DIR), timeout=600)
        job_id = JOB_CTX["id"]
        job = JOBS[job_id]
        job["output"] = out[-20000:]
        pkg_name = package_name_of(spec)
        if code == 0 and pkg_name:
            try:
                pkg = profile_pkg()
                bundles = pkg.setdefault("dsh", {}).setdefault("profile", {}).setdefault("bundles", [])
                if pkg_name not in bundles:
                    bundles.append(pkg_name)
                    save_profile_pkg(pkg)
                    job["output"] += f"\n[已加入 bundles] {pkg_name}（重启 DSH 生效）"
            except Exception as e:  # noqa: BLE001
                job["output"] += f"\n[写入 bundles 失败] {e}"
        job["code"] = code
        job["done"] = True

    return _spawn_job(f"安装 npm 包 {spec}", worker)


def package_name_of(spec: str) -> str:
    m = re.match(r"^(?:npm:)?(@?[^@/]+(?:/[^@]+)?)", spec)
    return m.group(1) if m else ""


def install_github_job(url: str) -> str:
    def worker() -> None:
        job = JOBS[JOB_CTX["id"]]
        url_clean = url.strip().rstrip("/")
        m = re.search(r"github\.com/([^/]+)/([^/#?]+)", url_clean)
        if not m:
            job["output"] = "看不懂这个地址，需要形如 https://github.com/owner/repo"
            job["code"] = 1
            job["done"] = True
            return
        owner, repo = m.group(1), m.group(2).removesuffix(".git")
        archive = f"https://gh-proxy.org/https://github.com/{owner}/{repo}/archive/refs/heads/main.zip"
        tmp_zip = Path(os.environ.get("TEMP", r"C:\Windows\Temp")) / f"{repo}.zip"
        job["output"] = f"下载 {archive}\n"
        try:
            req = urllib.request.Request(archive, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=180) as r, open(tmp_zip, "wb") as f:
                shutil.copyfileobj(r, f)
        except Exception:
            archive = f"https://gh-proxy.org/https://github.com/{owner}/{repo}/archive/refs/heads/master.zip"
            job["output"] += "main 分支失败，试 master\n"
            try:
                req = urllib.request.Request(archive, headers={"User-Agent": "Mozilla/5.0"})
                with urllib.request.urlopen(req, timeout=180) as r, open(tmp_zip, "wb") as f:
                    shutil.copyfileobj(r, f)
            except Exception as e:  # noqa: BLE001
                job["output"] += f"[下载失败] {e}"
                job["code"] = 1
                job["done"] = True
                return
        extract = Path(os.environ.get("TEMP", r"C:\Windows\Temp")) / f"{repo}-extract"
        shutil.rmtree(extract, ignore_errors=True)
        with zipfile.ZipFile(tmp_zip) as z:
            z.extractall(extract)
        roots = [p for p in extract.iterdir() if p.is_dir()]
        src = roots[0] if roots else extract
        pkg_json = src / "package.json"
        if not pkg_json.exists():
            job["output"] += "压缩包里没有 package.json，不像 DSH 插件"
            job["code"] = 1
            job["done"] = True
            return
        meta = json.loads(pkg_json.read_text(encoding="utf-8"))
        name = meta.get("name") or repo
        dest = PLUGINS_DIR / name.replace("/", "-")
        shutil.rmtree(dest, ignore_errors=True)
        shutil.copytree(src, dest)
        job["output"] += f"已解压到 {dest}（版本 {meta.get('version', '?')}）\n"
        code, out = run([NODE, PNPM, "add", f"link:{dest.as_posix()}"], cwd=str(PROFILE_DIR), timeout=600)
        job["output"] += out[-12000:]
        if code == 0:
            try:
                pkg = profile_pkg()
                deps = pkg.setdefault("dependencies", {})
                deps[name] = f"link:{dest.as_posix()}"
                bundles = pkg.setdefault("dsh", {}).setdefault("profile", {}).setdefault("bundles", [])
                if name not in bundles:
                    bundles.append(name)
                save_profile_pkg(pkg)
                job["output"] += f"\n[已登记] {name} → 重启 DSH 生效"
            except Exception as e:  # noqa: BLE001
                job["output"] += f"\n[登记失败] {e}"
        job["code"] = code
        job["done"] = True

    return _spawn_job(f"安装 GitHub 插件 {url}", worker)


def install_pip_job(spec: str) -> str:
    def worker() -> None:
        job = JOBS[JOB_CTX["id"]]
        code, out = run([VOICE_PY, "-m", "pip", "install", *spec.split()], timeout=3600)
        job["output"] = out[-20000:]
        job["code"] = code
        job["done"] = True

    return _spawn_job(f"安装 Python 包 {spec}", worker)


JOB_CTX = {"id": ""}


def _spawn_job(title: str, fn) -> str:
    job_id = uuid.uuid4().hex[:12]
    with JOBS_LOCK:
        JOBS[job_id] = {"id": job_id, "title": title, "output": "", "done": False,
                        "code": None, "started": time.time()}
    JOB_CTX["id"] = job_id
    threading.Thread(target=fn, daemon=True).start()
    return job_id


# ---------------------------------------------------------------- doctor
def doctor_script() -> Path:
    return BRIDGE_DIR / "scripts" / "doctor.mjs"


def run_doctor(fix: str | None = None) -> dict:
    """跑体检脚本，返回它的 JSON。fix 传修复 id 或 'all'。"""
    script = doctor_script()
    if not script.exists():
        return {"ok": False, "error": "没找到 scripts/doctor.mjs", "verdict": "体检脚本缺失"}
    node = NODE or _node()
    if not node:
        return {"ok": False, "error": "找不到 node.exe", "verdict": "node 未安装"}
    cmd = [node, str(script), "--json"]
    if fix:
        cmd += ["--fix", fix]
    code, out = run(cmd, cwd=str(BRIDGE_DIR), timeout=180.0)
    # doctor 可能把日志混进 stdout，取最后一个完整 JSON 对象
    text = out.strip()
    start = text.find("{")
    if start < 0:
        return {"ok": False, "error": (out or "")[-800:], "verdict": f"体检脚本没有输出（退出码 {code}）"}
    try:
        return json.loads(text[start:])
    except ValueError:
        # 逐行回溯，找能解析的那一行
        for line in reversed(text.splitlines()):
            line = line.strip()
            if line.startswith("{") and line.endswith("}"):
                try:
                    return json.loads(line)
                except ValueError:
                    continue
        return {"ok": False, "error": text[-800:], "verdict": "体检输出无法解析"}


# ---------------------------------------------------------------- logs
def _guard_log() -> Path:
    """网关守护日志。守护脚本通常放在 SnowLuma 目录或其父目录。"""
    for p in (SNOWLUMA_DIR / "snowluma-guard.log", SNOWLUMA_DIR.parent / "snowluma-guard.log"):
        if p.exists():
            return p
    return SNOWLUMA_DIR / "snowluma-guard.log"


LOG_FILES = {
    "bridge": BRIDGE_DIR / "state" / "bridge.log",
    "activity": BRIDGE_DIR / "state" / "qq-activity.log",
    "guard": _guard_log(),
    "doctor": BRIDGE_DIR / "state" / "doctor.log",
}


def tail_lines(path: Path, n: int) -> list[str]:
    try:
        with open(path, "rb") as f:
            f.seek(0, os.SEEK_END)
            size = f.tell()
            block = 64 * 1024
            data = b""
            while size > 0 and data.count(b"\n") <= n:
                step = min(block, size)
                size -= step
                f.seek(size)
                data = f.read(step) + data
            text = data.decode("utf-8", "replace")
            return text.splitlines()[-n:]
    except OSError:
        return []


# ---------------------------------------------------------------- http
PLUGIN_PREFIX = "/dsh-bigfish"


def _strip_prefix(path: str) -> str:
    """插件反代时前缀不一定被剥掉。

    新版插件（index.js 的 upstreamPath）会在转发前把 /dsh-bigfish 切掉；
    老版本插件（以及 DSH 还没重启、跑着旧代码的窗口期）会原样转发
    /dsh-bigfish/api/status 过来，于是后台一律 404。
    这里两边都认：带前缀就自己剥，不带就原样用。
    """
    if path == PLUGIN_PREFIX:
        return "/"
    if path.startswith(PLUGIN_PREFIX + "/"):
        return path[len(PLUGIN_PREFIX):] or "/"
    return path


class Handler(BaseHTTPRequestHandler):
    server_version = "DafeiyuAdmin/1.0"

    def log_message(self, *_args) -> None:  # silence
        pass

    def _send(self, code: int, body: bytes, ctype: str = "application/json; charset=utf-8") -> None:
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj, code: int = 200) -> None:
        self._send(code, json.dumps(obj, ensure_ascii=False).encode("utf-8"))

    def _body(self) -> dict:
        try:
            n = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(n) if n else b"{}"
            return json.loads(raw.decode("utf-8") or "{}")
        except Exception:
            return {}

    # ---- GET
    def do_GET(self) -> None:  # noqa: N802
        parsed = urllib.parse.urlparse(self.path)
        path, qs = parsed.path, urllib.parse.parse_qs(parsed.query)
        path = _strip_prefix(path)
        if path in ("/", "/index.html"):
            ui = HERE / "ui.html"
            self._send(200, ui.read_bytes(), "text/html; charset=utf-8")
            return
        if path.startswith("/assets/"):
            # 说明页里的图（比如投喂二维码）走这里，禁止 ../ 穿越
            rel = path[len("/assets/"):]
            target = (ASSETS_DIR / rel).resolve()
            try:
                inside = target.is_relative_to(ASSETS_DIR.resolve())
            except AttributeError:  # Python < 3.9
                inside = str(target).startswith(str(ASSETS_DIR.resolve()))
            if not inside or not target.is_file():
                self._json({"error": "not found"}, 404)
                return
            ctype = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
            self._send(200, target.read_bytes(), ctype)
            return
        if path == "/api/status":
            st = bridge_status()
            self._json({
                "bridge": st,
                "online": st is not None,
                "snowluma_pids": snowluma_pids(),
                "guard_log_tail": tail_lines(LOG_FILES["guard"], 3),
                "now": time.strftime("%Y-%m-%d %H:%M:%S"),
            })
            return
        if path == "/api/logs":
            kind = (qs.get("kind") or ["bridge"])[0]
            n = min(int((qs.get("lines") or ["200"])[0]), 2000)
            f = LOG_FILES.get(kind)
            if not f:
                self._json({"error": "未知日志"}, 400)
                return
            self._json({"kind": kind, "lines": tail_lines(f, n)})
            return
        if path == "/api/roles":
            roles = [p.stem for p in (BRIDGE_DIR / "roles").glob("*.md") if p.stem != "README"]
            self._json({"roles": roles})
            return
        if path == "/api/modules":
            self._json({"plugins": installed_plugins(), "voice_py": VOICE_PY})
            return
        if path == "/api/targets":
            wl = whitelist()
            allow = wl.get("allow") or {}
            st = bridge_status() or {}
            self._json({
                "private": [int(x) for x in (allow.get("private") or [])],
                "groups": [int(x) for x in (allow.get("groups") or [])],
                "ownerQQ": wl.get("ownerQQ"),
                "mode": st.get("mode"),
                "activity": st.get("activity") or "",
            })
            return
        if path == "/api/job":
            job_id = (qs.get("id") or [""])[0]
            job = JOBS.get(job_id)
            if not job:
                self._json({"error": "任务不存在"}, 404)
                return
            self._json(job)
            return
        if path == "/api/doctor":
            self._json(run_doctor())
            return
        self._json({"error": "not found"}, 404)

    # ---- POST
    def do_POST(self) -> None:  # noqa: N802
        parsed = urllib.parse.urlparse(self.path)
        path = _strip_prefix(parsed.path)
        body = self._body()
        try:
            if path == "/api/bridge/restart":
                bridge_call("/api/restart", "POST", {})
                self._json({"ok": True, "message": "桥接正在重启"})
                return
            if path == "/api/snowluma/restart":
                msg = restart_snowluma()
                self._json({"ok": True, "message": msg})
                return
            if path == "/api/dsh/restart":
                restart_dsh(int(body.get("delay") or 6))
                self._json({"ok": True, "message": "DSH 将在几秒后关闭并自动重开"})
                return
            if path == "/api/session/reset":
                key = body.get("key", "")
                r = bridge_call("/api/session/reset", "POST", {"key": key})
                self._json({"ok": True, "result": r})
                return
            if path == "/api/doctor/fix":
                fix = str(body.get("fix") or "").strip()
                if not fix:
                    self._json({"error": "缺少 fix 参数"}, 400)
                    return
                self._json(run_doctor(fix))
                return
            if path == "/api/mode":
                r = bridge_call("/api/mode", "POST", {"mode": body.get("mode", "reserved2")})
                self._json({"ok": True, "result": r})
                return
            if path == "/api/role":
                r = bridge_call("/api/role", "POST", {"role": body.get("role", "")})
                self._json({"ok": True, "result": r})
                return
            if path == "/api/target/add":
                parsed_key = parse_key(body.get("key", ""))
                if not parsed_key:
                    self._json({"error": "格式应为 QQ号 / group:群号 / private:QQ号"}, 400)
                    return
                kind, tid = parsed_key
                wl = whitelist()
                allow = {
                    "private": list((wl.get("allow") or {}).get("private") or []),
                    "groups": list((wl.get("allow") or {}).get("groups") or []),
                }
                bucket = "groups" if kind == "group" else "private"
                if tid not in [int(x) for x in allow[bucket]]:
                    allow[bucket].append(tid)
                save_allow(allow)
                self._json({"ok": True, "message": f"已加入白名单：{'群' if kind == 'group' else '好友'} {tid}"})
                return
            if path == "/api/target/remove":
                parsed_key = parse_key(body.get("key", ""))
                if not parsed_key:
                    self._json({"error": "目标格式不对"}, 400)
                    return
                kind, tid = parsed_key
                wl = whitelist()
                bucket = "groups" if kind == "group" else "private"
                allow = {
                    "private": [int(x) for x in ((wl.get("allow") or {}).get("private") or [])],
                    "groups": [int(x) for x in ((wl.get("allow") or {}).get("groups") or [])],
                }
                allow[bucket] = [x for x in allow[bucket] if x != tid]
                save_allow(allow)
                self._json({"ok": True, "message": f"已移出白名单：{tid}"})
                return
            if path == "/api/target/say":
                key = str(body.get("key", "")).strip()
                text = str(body.get("text", "")).strip()
                if not KEY_RE.match(key):
                    self._json({"error": "会话 key 格式应为 private:QQ号 或 group:群号"}, 400)
                    return
                if not text:
                    self._json({"error": "内容不能为空"}, 400)
                    return
                msg = (f"主人让你现在给这个会话发一条消息，内容是：「{text}」。"
                       f"用你自己的语气说，不要解释这是主人让你说的，也不要提后台。")
                wake_agent(key, msg)
                self._json({"ok": True, "message": f"已让她发往 {key}"})
                return
            if path == "/api/target/greet":
                key = str(body.get("key", "")).strip()
                if not KEY_RE.match(key):
                    self._json({"error": "会话 key 格式应为 private:QQ号 或 group:群号"}, 400)
                    return
                msg = ("主人让你主动找对方聊两句：挑一个自然的开场（问问在干嘛、吃饭了没、"
                       "今天过得怎么样都行），别太刻意，两三句就够，别一上来就道歉或解释。")
                wake_agent(key, msg)
                self._json({"ok": True, "message": f"已让她主动找 {key}"})
                return
            if path == "/api/install":
                kind, spec = body.get("kind", ""), (body.get("spec") or "").strip()
                if not spec:
                    self._json({"error": "内容为空"}, 400)
                    return
                if kind == "npm":
                    job = install_npm_job(spec)
                elif kind == "github":
                    job = install_github_job(spec)
                elif kind == "pip":
                    job = install_pip_job(spec)
                else:
                    self._json({"error": "未知类型"}, 400)
                    return
                self._json({"ok": True, "job": job})
                return
        except urllib.error.HTTPError as e:
            self._json({"error": f"桥接返回 {e.code}"}, 502)
            return
        except Exception as e:  # noqa: BLE001
            self._json({"error": str(e)}, 500)
            return
        self._json({"error": "not found"}, 404)


def main() -> None:
    srv = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"大肥鱼后台 -> http://{HOST}:{PORT}")
    srv.serve_forever()


if __name__ == "__main__":
    main()