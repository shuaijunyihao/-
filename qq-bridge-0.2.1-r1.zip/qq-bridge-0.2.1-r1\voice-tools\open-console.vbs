' Read the console token at click time and open the console in Edge.
' Edge is launched by full path on purpose: this machine's http/.url file
' associations are broken, so ShellExecute on a bare URL fails.
Set fso = CreateObject("Scripting.FileSystemObject")
Set f = fso.OpenTextFile("C:\Users\Administrator\Documents\deepseek-harness\default-workspace\qq-bridge-main\state\console-token", 1)
tok = Trim(f.ReadAll)
f.Close
url = "http://127.0.0.1:3100/?token=" & tok
cmd = """" & "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" & """" & " " & """" & url & """"
Set sh = CreateObject("WScript.Shell")
sh.Run cmd, 1, False
