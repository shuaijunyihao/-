import os, sys, threading, time, urllib.request

URL = "https://mirrors.aliyun.com/pytorch-wheels/cu121/torch-2.5.0+cu121-cp312-cp312-win_amd64.whl"
OUT = os.path.join(os.environ["TEMP"], "torch-2.5.0+cu121-cp312-cp312-win_amd64.whl")
THREADS = 8

req = urllib.request.Request(URL, method="HEAD", headers={"User-Agent": "curl/8"})
with urllib.request.urlopen(req, timeout=30) as r:
    total = int(r.headers["Content-Length"])
print(f"总大小 {total/1024/1024:.0f} MB", flush=True)

chunk = total // THREADS
parts = []
lock = threading.Lock()
done = [0]


def worker(i):
    start = i * chunk
    end = total - 1 if i == THREADS - 1 else (i + 1) * chunk - 1
    path = f"{OUT}.part{i}"
    parts.append(path)
    have = 0
    for attempt in range(6):
        try:
            req = urllib.request.Request(
                URL, headers={"User-Agent": "curl/8", "Range": f"bytes={start + have}-{end}"}
            )
            with urllib.request.urlopen(req, timeout=60) as r, open(path, "ab") as f:
                while True:
                    buf = r.read(262144)
                    if not buf:
                        break
                    f.write(buf)
                    have += len(buf)
                    with lock:
                        done[0] += len(buf)
            break
        except Exception as e:
            print(f"[{i}] 重试 {attempt}: {e}", flush=True)
            time.sleep(2)
    return have


start_t = time.time()
ths = [threading.Thread(target=worker, args=(i,)) for i in range(THREADS)]
for t in ths:
    t.start()
while any(t.is_alive() for t in ths):
    time.sleep(5)
    el = time.time() - start_t
    print(f"\r进度 {done[0]/1024/1024:.0f}/{total/1024/1024:.0f} MB  "
          f"{done[0]/1024/1024/el:.2f} MB/s", end="", flush=True)

print("", flush=True)
with open(OUT, "wb") as out:
    for p in sorted(parts, key=lambda x: int(x.split(".part")[-1])):
        with open(p, "rb") as f:
            while True:
                buf = f.read(1048576)
                if not buf:
                    break
                out.write(buf)
        os.remove(p)
size = os.path.getsize(OUT)
print(f"完成: {size/1024/1024:.0f} MB (应为 {total/1024/1024:.0f} MB)", flush=True)
print("OK" if size == total else "大小不符!", flush=True)
