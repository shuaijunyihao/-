#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""一次性重建整个语音库（说话 + 唱歌）"""
import os
import sys
import subprocess

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gen

AUDIO = gen.AUDIO_DIR
SONGS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "songs")

LINES = [
    ("在的在的", "在的在的，我在呢"),
    ("好耶", "好耶！"),
    ("才不理你", "哼，才不理你"),
    ("晚安", "晚安啦，早点睡，别熬夜"),
    ("让我想想", "让我想想哦……"),
    ("哈哈哈", "哈哈哈哈"),
    ("真的假的", "真的假的呀？"),
    ("你说啥", "啊？你说啥"),
    ("困了", "我有点困了……"),
    ("收到收到", "收到收到"),
    ("哎呀", "哎呀，别闹"),
    ("牛啊", "哇，牛啊"),
]

SONG_TASKS = [
    ("twotigers.txt", "唱两只老虎", 132),
    ("twinkle.txt", "唱小星星", 118),
    ("birthday.txt", "唱生日快乐", 108),
]

OLD_BAD = ["在的在的.wav", "好耶.wav", "才不理你.wav", "晚安.wav", "让我想想.wav"]


def main():
    os.makedirs(AUDIO, exist_ok=True)
    # 清掉旧的机器音和测试文件
    for f in os.listdir(AUDIO):
        path = os.path.join(AUDIO, f)
        if f.lower().endswith((".wav", ".mp3")) and (
            f in OLD_BAD or f.startswith("tmp_") or f.startswith("测试_")
        ):
            os.remove(path)
            print("删除", f, flush=True)

    for name, text in LINES:
        try:
            out = gen.say(text, name)
            print("OK  说话", name, "%.2fs" % gen.ffprobe_duration(out), flush=True)
        except Exception as e:
            print("FAIL 说话", name, e, flush=True)

    for fn, name, bpm in SONG_TASKS:
        try:
            with open(os.path.join(SONGS, fn), "r", encoding="utf-8") as f:
                phrases = gen.parse_phrases(f.read())
            out = gen.sing_phrases(phrases, name, bpm=bpm)
            print("OK  唱歌", name, "%.2fs" % gen.ffprobe_duration(out), flush=True)
        except Exception as e:
            print("FAIL 唱歌", name, e, flush=True)

    print("=== 完成 ===", flush=True)


if __name__ == "__main__":
    main()
