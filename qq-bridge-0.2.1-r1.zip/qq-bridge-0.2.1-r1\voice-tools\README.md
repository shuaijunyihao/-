# 语音库工具（说话 + 唱歌）

一句话：**换掉了原来那个机械音，改成微软 Edge 的神经网络音色（晓伊，活泼少女音），并且加了真·唱歌功能。**

## 现在的语音库（qq-bridge/audio/）

| 类别 | 文件 | 内容 |
|---|---|---|
| 说话 | 在的在的 / 好耶 / 才不理你 / 晚安 / 让我想想 / 哈哈哈 / 真的假的 / 你说啥 / 困了 / 收到收到 / 哎呀 / 牛啊 | 12 条日常口吻短句 |
| 唱歌 | 唱两只老虎（21s）/ 唱小星星（31s）/ 唱生日快乐（17s）| 按简谱逐字合成、逐个音变调 |

全部 16kHz 单声道 PCM，QQ 语音条能直接播。

## 加新的一句话

```powershell
$py = "C:\Users\Administrator\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe"
& $py gen.py say "你说得对，但是我不听" 不听了
```

生成的文件名就是 `audio/不听了.wav`，机器人能用 `qq_list_voices` 看到、`qq_send_voice` 发出去。

## 加一首新歌

1. 在 `songs/` 里新建一个 txt，一行一个音，格式：`字 音名 拍数`

```
# 例子：小星星开头
一 C4 1
闪 C4 1
一 C4 1
闪 G4 1
```

音名支持 `C4 D#4 F#5 A4` 这种；`rest`/`0` 表示休止。

2. 渲染：

```powershell
& $py gen.py sing songs\新歌.txt 唱新歌
# 可选速度：默认 100 BPM，慢歌可改 gen.sing(..., bpm=80)
```

## 原理（为什么能唱歌）

1. `edge-tts` 逐字合成（每个字单独一次请求）。—— 需要联网，微软免费接口，无需 key
2. 用 **YIN 算法**测出这个字实际唱的基频
3. `ffmpeg rubberband` 把它变调到目标音高（`formant=preserved` 保留音色，不会变机器人），再拉伸到目标拍长
4. 变调后再测一遍，误差 >2% 就再修一次（最多 3 轮）
5. 全部拼接、统一响度（loudnorm -16 LUFS）

所以它唱的音高是准的，听感是“这个音色在唱歌”，不是把说话声硬拉长。

## 已知限制

- 每个字起音处会有一点点“一个字一个字”的颗粒感（这是逐字合成的代价，要彻底消除得上 RVC/SVC 声码器，几百 MB 模型 + GPU）
- 每首歌多长就生成多久：31 秒的小星星大约要 30-40 秒渲染
- edge-tts 依赖微软接口，断网时生成会失败（已生成的 wav 不受影响）

## 换音色

`gen.py` 里 `VOICES` 字典：

| 键 | 音色 | 感觉 |
|---|---|---|
| xiaoyi（默认）| zh-CN-XiaoyiNeural | 活泼少女、卡通感 |
| xiaoxiao | zh-CN-XiaoxiaoNeural | 温柔、邻家 |
| yunxia | zh-CN-YunxiaNeural | 正太音（男）|
| xiaobei | zh-CN-liaoning-XiaobeiNeural | 东北话，喜感 |

另外 `DEFAULT_PITCH = "+12Hz"` 控制整体音高，想更萝莉调高（+25Hz），想成熟调低（+0Hz）。
