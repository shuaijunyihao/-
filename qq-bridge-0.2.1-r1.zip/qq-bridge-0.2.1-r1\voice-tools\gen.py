#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
语音库生成器（edge-tts + ffmpeg）

用法：
  python gen.py say "在的在的，我在呢" 在的在的
  python gen.py sing song.txt 两只老虎
  python gen.py list

依赖：edge-tts（已装在 DSH 自带 python 里）、ffmpeg、numpy
输出：../audio/<名字>.wav  （16kHz 单声道，QQ 语音条标准格式）
"""
import os
import sys
import json
import math
import shutil
import asyncio
import subprocess
import tempfile
import wave

import numpy as np
import edge_tts

HERE = os.path.dirname(os.path.abspath(__file__))
AUDIO_DIR = os.path.abspath(os.path.join(HERE, "..", "audio"))
FFMPEG = r"C:\Users\Administrator\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe"
FFPROBE = FFMPEG.replace("ffmpeg.exe", "ffprobe.exe")

# 音色：Xiaoyi 是 Cartoon/Lively（活泼萝莉感），Xiaoxiao 是 Warm（温柔）
DEFAULT_VOICE = "zh-CN-XiaoyiNeural"
VOICES = {
    "xiaoyi": "zh-CN-XiaoyiNeural",
    "xiaoxiao": "zh-CN-XiaoxiaoNeural",
    "yunxia": "zh-CN-YunxiaNeural",
    "xiaobei": "zh-CN-liaoning-XiaobeiNeural",
}

NOTE_BASE = {"C": 0, "C#": 1, "D": 2, "D#": 3, "E": 4, "F": 5,
             "F#": 6, "G": 7, "G#": 8, "A": 9, "A#": 10, "B": 11}


def note_to_freq(note):
    """C4 -> 261.63 ; 支持 C#4 / Db4"""
    note = note.strip()
    if note.endswith("b") and len(note) > 2:
        # 降号转升号
        base = note[:-1]
        for k, v in NOTE_BASE.items():
            if k[0] == base[0]:
                note = k[:-1] + "#" + base[-1] if len(k) > 1 else base
                break
    i = 2 if len(note) > 2 and note[1] == "#" else 1
    name, octave = note[:i], int(note[i:])
    semis = NOTE_BASE[name] + (octave - 4) * 12
    return 440.0 * (2 ** ((semis - 9) / 12.0))


def run(cmd):
    p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if p.returncode != 0:
        raise RuntimeError(f"命令失败: {' '.join(cmd)}\n{p.stderr[-1200:]}")
    return p.stdout


def ffprobe_duration(path):
    out = run([FFPROBE, "-v", "error", "-show_entries", "format=duration",
               "-of", "default=nw=1:nk=1", path])
    return float(out.strip())


def wav_to_mono_f32(path):
    with wave.open(path, "rb") as w:
        n = w.getnframes()
        sr = w.getframerate()
        ch = w.getnchannels()
        raw = w.readframes(n)
    data = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
    if ch > 1:
        data = data.reshape(-1, ch).mean(axis=1)
    return data, sr


def yin_f0(seg, sr, fmin=70.0, fmax=800.0, threshold=0.12):
    """YIN 基频估计（比自相关抗八度错误）"""
    seg = np.asarray(seg, dtype=np.float64)
    seg = seg - seg.mean()
    if len(seg) < sr / fmin * 1.2 or np.max(np.abs(seg)) < 1e-4:
        return 0.0
    tau_min = max(2, int(sr / fmax))
    tau_max = min(len(seg) // 2, int(sr / fmin))
    if tau_max <= tau_min + 2:
        return 0.0
    n = tau_max + 1
    d = np.empty(tau_max + 1)
    for tau in range(tau_max + 1):
        a = seg[: len(seg) - tau]
        b = seg[tau:]
        m = min(len(a), len(b))
        diff = a[:m] - b[:m]
        d[tau] = float(np.dot(diff, diff))
    cmnd = np.ones_like(d)
    running = 0.0
    for tau in range(1, tau_max + 1):
        running += d[tau]
        cmnd[tau] = d[tau] * tau / running if running > 0 else 1.0
    cand = None
    for tau in range(tau_min, tau_max + 1):
        if cmnd[tau] < threshold:
            while tau + 1 <= tau_max and cmnd[tau + 1] < cmnd[tau]:
                tau += 1
            cand = tau
            break
    if cand is None:
        region = cmnd[tau_min:tau_max + 1]
        cand = tau_min + int(np.argmin(region))
        if cmnd[cand] > 0.45:
            return 0.0
    # 抛物线插值
    if 0 < cand < tau_max:
        a, b, c = cmnd[cand - 1], cmnd[cand], cmnd[cand + 1]
        denom = (a - 2 * b + c)
        shift = 0.5 * (a - c) / denom if abs(denom) > 1e-9 else 0.0
        return sr / (cand + shift)
    return sr / cand


def estimate_f0_mid(path, fmin=70.0, fmax=800.0):
    """只测中间 60% 的基频，避开起音和尾音"""
    data, sr = wav_to_mono_f32(path)
    n = len(data)
    if n < sr * 0.05:
        return 0.0
    seg = data[int(n * 0.2):int(n * 0.8)]
    frame = int(sr * 0.04)
    hop = int(sr * 0.01)
    vals = []
    for start in range(0, max(1, len(seg) - frame), hop):
        w = seg[start:start + frame]
        if len(w) < frame or np.max(np.abs(w)) < 0.01:
            continue
        f0 = yin_f0(w.astype(np.float64), sr, fmin, fmax)
        if f0 > 0:
            vals.append(f0)
    if not vals:
        return estimate_f0(path, fmin, fmax)
    return float(np.median(vals))


def estimate_f0(path, fmin=70.0, fmax=800.0):
    """对整段音频分帧取中位数基频"""
    data, sr = wav_to_mono_f32(path)
    if len(data) < sr * 0.06:
        return 0.0
    frame = int(sr * 0.04)
    hop = int(sr * 0.02)
    vals = []
    for start in range(0, len(data) - frame, hop):
        seg = data[start:start + frame]
        if np.max(np.abs(seg)) < 0.01:
            continue
        f0 = yin_f0(seg.astype(np.float64), sr, fmin, fmax)
        if f0 > 0:
            vals.append(f0)
    if not vals:
        return 0.0
    return float(np.median(vals))


# 默认把音调抬高一点，更像活泼的少女音（+0 为原声）
DEFAULT_PITCH = "+12Hz"
DEFAULT_RATE = "+0%"


async def _tts(text, voice, out_mp3, pitch=DEFAULT_PITCH, rate=DEFAULT_RATE):
    comm = edge_tts.Communicate(text, voice, pitch=pitch, rate=rate)
    await comm.save(out_mp3)


def tts_raw(text, voice, out_mp3, pitch=DEFAULT_PITCH, rate=DEFAULT_RATE):
    asyncio.run(_tts(text, voice, out_mp3, pitch, rate))


def to_wav16(src, dst):
    """转 16k 单声道 wav，并做响度归一"""
    run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-i", src,
         "-af", "loudnorm=I=-16:TP=-1.5:LRA=11",
         "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le", dst])


# 音色引擎：f5 = 本地克隆（曼波音色），edge = 微软在线 TTS（旧）
ENGINE = os.environ.get("VOICE_ENGINE", "f5")

# 音色风格：normal = 原样；cute = 微升调 + 轻压缩，听感更软更小只
STYLE = os.environ.get("VOICE_STYLE", "normal")
_STYLE_AF = {
    "cute": "rubberband=pitch=1.055:formant=preserved,highpass=f=110,"
            "acompressor=threshold=-20dB:ratio=2.5:attack=8:release=120,"
            "treble=g=1.5",
}


def apply_style(src, dst):
    """按 STYLE 做后处理；normal 直接复制"""
    af = _STYLE_AF.get(STYLE)
    if not af:
        shutil.copyfile(src, dst)
        return dst
    run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-i", src,
         "-af", af, "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le", dst])
    return dst


def say(text, name, voice=DEFAULT_VOICE, speed=1.0):
    os.makedirs(AUDIO_DIR, exist_ok=True)
    out = os.path.join(AUDIO_DIR, f"{name}.wav")
    if ENGINE == "f5":
        import f5_backend

        raw = os.path.join(tempfile.gettempdir(), f"f5_{abs(hash(text)) % 10**8}.wav")
        f5_backend.synth(text, raw, speed=speed)
        styled = os.path.join(tempfile.gettempdir(), f"f5_st_{abs(hash(text)) % 10**8}.wav")
        to_wav16(raw, styled)
        apply_style(styled, out)
        for p in (raw, styled):
            try:
                os.remove(p)
            except OSError:
                pass
        return out

    tmp = os.path.join(tempfile.gettempdir(), f"tts_{abs(hash(text)) % 10**8}.mp3")
    tts_raw(text, voice, tmp)
    to_wav16(tmp, out)
    os.remove(tmp)
    return out


def _sing_syllable(char, target_freq, duration, voice, idx):
    """合成一个音节并变调到目标音高、拉伸到目标时长"""
    tmp = os.path.join(tempfile.gettempdir(), f"sing_{idx}.mp3")
    tts_raw(char, voice, tmp)
    wav = os.path.join(tempfile.gettempdir(), f"sing_{idx}.wav")
    to_wav16(tmp, wav)

    f0 = estimate_f0_mid(wav)
    ratio = 1.0
    if f0 > 0:
        ratio = target_freq / f0
        ratio = float(min(2.2, max(0.45, ratio)))

    cur = ffprobe_duration(wav)
    tempo = 1.0
    if cur > 0:
        tempo = float(min(2.0, max(0.5, cur / max(0.08, duration))))

    out = os.path.join(tempfile.gettempdir(), f"sing_{idx}_out.wav")
    af = f"rubberband=pitch={ratio:.4f}:formant=preserved,atempo={tempo:.4f},aformat=channel_layouts=mono"
    run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-i", wav, "-af", af,
         "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le", out])

    # 迭代校正：最多 3 轮，直到音高误差 <2%
    for k in range(3):
        f2 = estimate_f0_mid(out)
        if f2 <= 0:
            break
        err = target_freq / f2
        if 0.98 <= err <= 1.02:
            break
        err = float(min(1.35, max(0.72, err)))
        out2 = out.replace(".wav", f"_c{k}.wav")
        run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-i", out,
             "-af", f"rubberband=pitch={err:.4f}:formant=preserved",
             "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le", out2])
        out = out2
    return out


def sing(score_lines, name, voice=DEFAULT_VOICE, bpm=100.0):
    """
    score_lines: [(char, note, beats), ...]  例如 [("两","C4",1), ("只","D4",1)]
    """
    os.makedirs(AUDIO_DIR, exist_ok=True)
    beat = 60.0 / bpm
    parts = []
    for i, (char, note, beats) in enumerate(score_lines):
        if char in ("-", "_", "0", "rest"):
            dur = beats * beat
            sil = os.path.join(tempfile.gettempdir(), f"rest_{i}.wav")
            run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error",
                 "-f", "lavfi", "-i", "anullsrc=r=16000:cl=mono",
                 "-t", f"{dur:.3f}", "-c:a", "pcm_s16le", sil])
            parts.append(sil)
            continue
        freq = note_to_freq(note)
        parts.append(_sing_syllable(char, freq, beats * beat, voice, i))

    listfile = os.path.join(tempfile.gettempdir(), "sing_list.txt")
    with open(listfile, "w", encoding="utf-8") as f:
        for p in parts:
            f.write(f"file '{p.replace(chr(92), '/')}'\n")
    joined = os.path.join(tempfile.gettempdir(), "sing_joined.wav")
    run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-f", "concat",
         "-safe", "0", "-i", listfile, "-c", "copy", joined])

    out = os.path.join(AUDIO_DIR, f"{name}.wav")
    run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-i", joined,
         "-af", "loudnorm=I=-16:TP=-1.5:LRA=11,afade=t=out:st=%s:d=0.15" % max(0, ffprobe_duration(joined) - 0.15),
         "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le", out])
    for p in parts:
        try:
            os.remove(p)
        except OSError:
            pass
    return out



# ───────────────────────── 整句式唱歌（更连贯） ─────────────────────────
def _read_wav_float(path):
    data, sr = wav_to_mono_f32(path)
    return data, sr


def _shift_file(src, ratio, out):
    run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-i", src,
         "-af", f"rubberband=pitch={ratio:.4f}:formant=preserved",
         "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le", out])
    return out


def atempo_chain(tempo):
    """把任意倍速转成 ffmpeg atempo 能接受的链（单级限 0.5~2.0）"""
    tempo = float(max(0.2, min(5.0, tempo)))
    parts = []
    while tempo < 0.5:
        parts.append("atempo=0.5")
        tempo /= 0.5
    while tempo > 2.0:
        parts.append("atempo=2.0")
        tempo /= 2.0
    parts.append(f"atempo={tempo:.4f}")
    return ",".join(parts)


def _stretch(src, dst, tempo):
    run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-i", src,
         "-af", atempo_chain(tempo), "-ar", "16000", "-ac", "1",
         "-c:a", "pcm_s16le", dst])
    return dst


def _trim_silence(src, dst, rel=0.02, pad_ms=8):
    """只裁掉首尾的静音（阈值：峰值的 2%），不动机身内部的气口"""
    data, sr = wav_to_mono_f32(src)
    if len(data) == 0:
        return src
    peak = float(np.max(np.abs(data)))
    if peak <= 0:
        return src
    thr = peak * rel
    idx = np.where(np.abs(data) >= thr)[0]
    if len(idx) == 0:
        return src
    pad = int(sr * pad_ms / 1000)
    a = max(0, int(idx[0]) - pad)
    b = min(len(data), int(idx[-1]) + pad)
    seg = data[a:b]
    with wave.open(dst, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes((np.clip(seg, -1, 1) * 32767).astype("<i2").tobytes())
    return dst


def sing_phrases(phrases, name, voice=DEFAULT_VOICE, bpm=100.0, cross_ms=18):
    """
    一句歌词只合成一次（保留自然连音），再按音符切段变调，段间做交叉淡入淡出。
    phrases: [[(char, note, beats), ...], ...]  内层是一个乐句
    """
    os.makedirs(AUDIO_DIR, exist_ok=True)
    beat = 60.0 / bpm
    sr = 16000
    pieces = []          # (起始时间, 波形) 时间用秒

    t_cursor = 0.0
    for pi, phrase in enumerate(phrases):
        notes = [x for x in phrase if x[0] not in ("-", "_", "0", "rest")]
        if not notes:
            continue
        text = "".join(x[0] for x in notes)
        total_beats = sum(x[2] for x in notes)
        target_dur = total_beats * beat

        raw_mp3 = os.path.join(tempfile.gettempdir(), f"ph_{pi}.mp3")
        raw_wav = os.path.join(tempfile.gettempdir(), f"ph_{pi}.wav")
        if ENGINE == "f5":
            import f5_backend

            f5_raw = os.path.join(tempfile.gettempdir(), f"ph_{pi}_f5.wav")
            f5_backend.synth(text, f5_raw, speed=0.9)
            to_wav16(f5_raw, raw_wav)
        else:
            tts_raw(text, voice, raw_mp3)
            to_wav16(raw_mp3, raw_wav)
        trimmed = os.path.join(tempfile.gettempdir(), f"ph_{pi}_trim.wav")
        _trim_silence(raw_wav, trimmed)

        cur = ffprobe_duration(trimmed)
        tempo = float(min(2.0, max(0.34, cur / max(0.2, target_dur))))
        stretched = os.path.join(tempfile.gettempdir(), f"ph_{pi}_st.wav")
        _stretch(trimmed, stretched, tempo)
        stretched_dur = ffprobe_duration(stretched)
        scale = target_dur / stretched_dur if stretched_dur > 0 else 1.0

        # 按拍数分配每个音的时间窗（用实际长度缩放）
        bounds = []
        acc = 0.0
        for ch, note, beats in notes:
            start = acc * beat * scale
            acc += beats
            end = acc * beat * scale
            bounds.append((start, end))

        buf = np.zeros(int((target_dur + 1.0) * sr), dtype=np.float32)
        for ni, ((ch, note, beats), (b0, b1)) in enumerate(zip(notes, bounds)):
            seg_wav = os.path.join(tempfile.gettempdir(), f"seg_{pi}_{ni}.wav")
            dur = b1 - b0
            run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-i", stretched,
                 "-af", f"atrim=start={max(0, b0 - 0.03):.3f}:end={b1 + 0.05:.3f},asetpts=PTS-STARTPTS",
                 "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le", seg_wav])
            f0 = estimate_f0_mid(seg_wav)
            target = note_to_freq(note)
            if f0 > 0 and target > 0:
                ratio = float(min(2.2, max(0.45, target / f0)))
                shifted = os.path.join(tempfile.gettempdir(), f"seg_{pi}_{ni}_s.wav")
                _shift_file(seg_wav, ratio, shifted)
                # 长音加颤音——这是"唱"和"说"最关键的听感差别
                if dur >= 0.32:
                    vib = os.path.join(tempfile.gettempdir(), f"seg_{pi}_{ni}_v.wav")
                    depth = min(0.9, 0.35 + dur * 0.35)
                    run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-i", shifted,
                         "-af", f"vibrato=f=5.4:d={depth:.2f}", "-ar", "16000", "-ac", "1",
                         "-c:a", "pcm_s16le", vib])
                    shifted = vib
                seg_wav = shifted
            data, _ = _read_wav_float(seg_wav)
            # 对齐到目标长度
            want = int(dur * sr)
            if len(data) > want:
                data = data[:want]
            elif len(data) < want:
                data = np.pad(data, (0, want - len(data)))
            # 边缘淡入淡出，避免爆音
            n_fade = int(0.035 * sr)
            if len(data) > 2 * n_fade:
                data[:n_fade] *= np.linspace(0, 1, n_fade) ** 0.6
                data[-n_fade:] *= np.linspace(1, 0, n_fade) ** 0.6
            pos = max(0, int(b0 * sr) - int(0.018 * sr))
            endpos = min(len(buf), pos + len(data))
            buf[pos:endpos] += data[: endpos - pos]
        pieces.append((t_cursor, buf))
        t_cursor += target_dur

    total = int((t_cursor + 0.3) * sr)
    out_buf = np.zeros(total, dtype=np.float32)
    for start, buf in pieces:
        pos = int(start * sr)
        end = min(total, pos + len(buf))
        out_buf[pos:end] += buf[: end - pos]

    peak = float(np.max(np.abs(out_buf)))
    if peak > 0:
        out_buf *= min(1.0, 0.89 / peak)
    raw_out = os.path.join(tempfile.gettempdir(), f"{name}_raw.wav")
    with wave.open(raw_out, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(16000)
        w.writeframes((np.clip(out_buf, -1, 1) * 32767).astype("<i2").tobytes())

    out = os.path.join(AUDIO_DIR, f"{name}.wav")
    pre = out + ".pre.wav"
    run([FFMPEG, "-y", "-hide_banner", "-loglevel", "error", "-i", raw_out,
         "-af", "aecho=0.7:0.6:38|55:0.22|0.12,loudnorm=I=-16:TP=-1.5:LRA=11",
         "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le", pre])
    apply_style(pre, out)
    try:
        os.remove(pre)
    except OSError:
        pass
    return out


def parse_phrases(text):
    """用 --- 作为乐句分隔"""
    phrases = []
    cur = []
    text = text.lstrip("\ufeff")
    for line in text.splitlines():
        line = line.replace("\ufeff", "").strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("---"):
            if cur:
                phrases.append(cur)
                cur = []
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        cur.append((parts[0], parts[1], float(parts[2]) if len(parts) > 2 else 1.0))
    if cur:
        phrases.append(cur)
    return phrases


def parse_score(text):
    """每行: 字 音符 拍数   以 # 开头为注释"""
    out = []
    text = text.lstrip("\ufeff")
    for line in text.splitlines():
        line = line.replace("\ufeff", "").strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        char = parts[0]
        note = parts[1]
        beats = float(parts[2]) if len(parts) > 2 else 1.0
        out.append((char, note, beats))
    return out


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return
    cmd = sys.argv[1]
    if cmd == "say":
        text, name = sys.argv[2], sys.argv[3]
        voice = VOICES.get(sys.argv[4], DEFAULT_VOICE) if len(sys.argv) > 4 else DEFAULT_VOICE
        print(say(text, name, voice))
    elif cmd == "sing":
        score_file, name = sys.argv[2], sys.argv[3]
        voice = VOICES.get(sys.argv[4], DEFAULT_VOICE) if len(sys.argv) > 4 else DEFAULT_VOICE
        with open(score_file, "r", encoding="utf-8") as f:
            score = parse_score(f.read())
        print(sing(score, name, voice))
    elif cmd == "list":
        d = AUDIO_DIR
        for f in sorted(os.listdir(d)):
            if f.lower().endswith(".wav"):
                p = os.path.join(d, f)
                print(f"{f}\t{ffprobe_duration(p):.2f}s\t{os.path.getsize(p) // 1024}KB")
    else:
        print(__doc__)


if __name__ == "__main__":
    main()
